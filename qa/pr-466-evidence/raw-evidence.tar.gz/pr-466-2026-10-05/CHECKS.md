# Executed assertion log

Recorded assertion counts: 1 CORRECTED, 5 FAIL, 1 INTERRUPTED, 441 PASS, 1 RESTORED. These counts are individual checks, not distinct end-to-end scenarios.

See [README.md](README.md) for the exact procedures, profile payloads and port mapping. [commands.log](evidence/commands.log) records executed commands and output. [results.jsonl](evidence/results.jsonl) preserves full observations, including certificate details omitted from these compact rows.

Assertions from aborted/retried stages remain in this chronological log. A PASS on a negative test means the expected rejection occurred. The HTTP ServiceMonitor reproduction is expected to demonstrate DOWN targets; its successful reproduction is still a product-documentation finding.

## baseline

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-001 | 06:57:10 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-002 | 06:57:24 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-003 | 06:57:25 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-004 | 06:57:25 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-005 | 06:57:25 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-006 | 06:57:25 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-007 | 06:57:25 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-008 | 06:57:25 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-009 | 06:57:25 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-010 | 06:57:25 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-011 | 06:57:25 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-012 | 06:57:25 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-013 | 06:57:25 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-014 | 06:57:25 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-015 | 06:57:26 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-016 | 06:57:26 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-017 | 06:57:26 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-018 | 06:57:26 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-019 | 06:57:26 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-020 | 06:57:26 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-021 | 06:57:26 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-022 | 06:57:26 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-023 | 06:57:26 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-024 | 06:57:26 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-025 | 06:57:26 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-026 | 06:57:26 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-027 | 06:57:26 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-028 | 06:57:26 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-029 | 06:57:26 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-030 | 06:57:26 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-031 | 06:57:28 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 13028} |
| QA-032 | 06:57:29 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-033 | 06:57:31 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92548} |
| QA-034 | 06:57:32 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-035 | 06:57:34 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 59600} |
| QA-036 | 06:57:35 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-037 | 06:57:37 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-038 | 06:57:39 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-039 | 06:57:40 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 06:57:40 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-040 | 06:57:43 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:57:43Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:57:43Z", "revision": 1} |
| QA-041 | 06:57:47 | PASS | Initial Bundle creation and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-042 | 06:57:48 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |
| QA-043 | 06:57:49 | PASS | RBAC cert-manager get cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-044 | 06:57:50 | PASS | RBAC cert-manager update cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-045 | 06:57:51 | CORRECTED | RBAC cert-manager update cmo-pr466-unrelated | yes: pre-existing certificate controller Secret permissions | yes; initial deny expectation was incorrect, see the scoped Role and existing ClusterRole checks |
| QA-046 | 06:57:52 | PASS | RBAC cert-manager-cainjector get cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-047 | 06:57:53 | PASS | RBAC cert-manager-cainjector update cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-048 | 06:57:54 | PASS | RBAC cert-manager-cainjector update cmo-pr466-unrelated | Assertion described by the check and README procedure holds | no |
| QA-049 | 06:57:56 | PASS | RBAC cert-manager-webhook get cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-050 | 06:57:57 | PASS | RBAC cert-manager-webhook update cert-manager-metrics-ca | Assertion described by the check and README procedure holds | yes |
| QA-051 | 06:57:58 | PASS | RBAC cert-manager-webhook update cmo-pr466-unrelated | Assertion described by the check and README procedure holds | no |

## strict-default

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-052 | 07:02:55 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-053 | 07:03:08 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-054 | 07:03:09 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-055 | 07:03:09 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-056 | 07:03:09 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-057 | 07:03:09 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-058 | 07:03:09 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-059 | 07:03:09 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-060 | 07:03:09 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-061 | 07:03:09 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-062 | 07:03:09 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-063 | 07:03:09 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-064 | 07:03:09 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-065 | 07:03:09 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-066 | 07:03:10 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-067 | 07:03:10 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-068 | 07:03:10 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-069 | 07:03:10 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-070 | 07:03:10 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-071 | 07:03:10 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-072 | 07:03:10 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-073 | 07:03:10 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-074 | 07:03:10 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-075 | 07:03:10 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-076 | 07:03:10 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-077 | 07:03:10 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-078 | 07:03:10 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-079 | 07:03:10 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-080 | 07:03:10 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-081 | 07:03:10 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-082 | 07:03:12 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14489} |
| QA-083 | 07:03:13 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-084 | 07:03:15 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92178} |
| QA-085 | 07:03:16 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-086 | 07:03:18 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56650} |
| QA-087 | 07:03:19 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-088 | 07:03:21 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-089 | 07:03:22 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-090 | 07:03:23 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:03:23 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-091 | 07:03:36 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:03:36Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 2, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:03:36Z", "revision": 2} |
| QA-092 | 07:03:42 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-093 | 07:03:43 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## strict-intermediate

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-094 | 07:03:50 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-095 | 07:04:04 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-096 | 07:04:04 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-097 | 07:04:04 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-098 | 07:04:05 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-099 | 07:04:05 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-100 | 07:04:05 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-101 | 07:04:05 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-102 | 07:04:05 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-103 | 07:04:05 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-104 | 07:04:05 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-105 | 07:04:05 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-106 | 07:04:05 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-107 | 07:04:05 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-108 | 07:04:05 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-109 | 07:04:05 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-110 | 07:04:06 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-111 | 07:04:06 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-112 | 07:04:06 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-113 | 07:04:06 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-114 | 07:04:06 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-115 | 07:04:06 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-116 | 07:04:06 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-117 | 07:04:06 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-118 | 07:04:06 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-119 | 07:04:06 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-120 | 07:04:06 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-121 | 07:04:06 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-122 | 07:04:06 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-123 | 07:04:06 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-124 | 07:04:08 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14504} |
| QA-125 | 07:04:09 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-126 | 07:04:11 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92174} |
| QA-127 | 07:04:12 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-128 | 07:04:13 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 59490} |
| QA-129 | 07:04:14 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-130 | 07:04:16 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-131 | 07:04:18 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-132 | 07:04:19 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:04:18 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-133 | 07:04:23 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:04:22Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 3, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:04:22Z", "revision": 3} |
| QA-134 | 07:04:27 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-135 | 07:04:27 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## strict-modern

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-136 | 07:05:00 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-137 | 07:06:21 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-138 | 07:06:40 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-139 | 07:06:41 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-140 | 07:06:41 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-141 | 07:06:41 | PASS | controller-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-142 | 07:06:41 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-143 | 07:06:41 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-144 | 07:06:41 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-145 | 07:06:41 | PASS | cainjector-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-146 | 07:06:41 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-147 | 07:06:41 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-148 | 07:06:41 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-149 | 07:06:41 | PASS | webhook-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-150 | 07:06:41 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-151 | 07:06:42 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-152 | 07:06:42 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-153 | 07:06:42 | PASS | cert-manager-webhook TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-154 | 07:06:42 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-155 | 07:06:42 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-156 | 07:06:42 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-157 | 07:06:42 | PASS | trust-manager-webhook TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-158 | 07:06:42 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-159 | 07:06:42 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-160 | 07:06:42 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-161 | 07:06:42 | FAIL | operator-existing TLS1.2 | reject | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-162 | 07:06:42 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-163 | 07:06:42 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-164 | 07:06:42 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-165 | 07:06:42 | PASS | operator-fresh TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-166 | 07:06:42 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-167 | 07:06:44 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14499} |
| QA-168 | 07:06:45 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-169 | 07:06:46 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92342} |
| QA-170 | 07:06:47 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-171 | 07:06:49 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56680} |
| QA-172 | 07:06:50 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-173 | 07:06:51 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-174 | 07:06:53 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-175 | 07:06:54 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:06:54 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-176 | 07:06:59 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:06:58Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 4, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:06:58Z", "revision": 4} |
| QA-177 | 07:07:06 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-178 | 07:07:07 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## strict-custom12

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-179 | 07:07:25 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-180 | 07:07:43 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-181 | 07:07:44 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-182 | 07:07:44 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-183 | 07:07:45 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-184 | 07:07:45 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-185 | 07:07:45 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-186 | 07:07:45 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-187 | 07:07:45 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-188 | 07:07:45 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-189 | 07:07:45 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-190 | 07:07:45 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-191 | 07:07:45 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-192 | 07:07:45 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-193 | 07:07:45 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-194 | 07:07:45 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-195 | 07:07:46 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-196 | 07:07:46 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-197 | 07:07:46 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-198 | 07:07:46 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-199 | 07:07:46 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-200 | 07:07:46 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-201 | 07:07:46 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-202 | 07:07:46 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-203 | 07:07:46 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-204 | 07:07:46 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-205 | 07:07:46 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-206 | 07:07:46 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-207 | 07:07:46 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-208 | 07:07:46 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-209 | 07:07:48 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14501} |
| QA-210 | 07:07:49 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-211 | 07:07:51 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92328} |
| QA-212 | 07:07:52 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-213 | 07:07:53 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56668} |
| QA-214 | 07:07:54 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-215 | 07:07:56 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-216 | 07:07:58 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-217 | 07:07:59 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:07:59 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-218 | 07:08:01 | PASS | controller-metrics Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-219 | 07:08:01 | PASS | controller-metrics Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-220 | 07:08:03 | PASS | cainjector-metrics Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-221 | 07:08:03 | PASS | cainjector-metrics Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-222 | 07:08:05 | PASS | webhook-metrics Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-223 | 07:08:05 | PASS | webhook-metrics Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-224 | 07:08:08 | PASS | cert-manager-webhook Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-225 | 07:08:08 | PASS | cert-manager-webhook Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-226 | 07:08:10 | PASS | trust-manager-webhook Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-227 | 07:08:10 | PASS | trust-manager-webhook Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-228 | 07:08:10 | PASS | operator-existing Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-229 | 07:08:10 | FAIL | operator-existing Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES256-GCM-SHA384"} |
| QA-230 | 07:08:10 | PASS | operator-fresh Custom allowed cipher | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-231 | 07:08:10 | PASS | operator-fresh Custom excluded cipher | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: SSLV3_ALERT_HANDSHAKE_FAILURE] ssl/tls alert handshake failure (_ssl.c:1082)"} |
| QA-232 | 07:08:15 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:08:15Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 5, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:08:15Z", "revision": 5} |
| QA-233 | 07:08:19 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-234 | 07:08:20 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## restore

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-235 | 07:08:28 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-236 | 07:08:39 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-237 | 07:09:07 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-238 | 07:09:08 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-282 | 07:14:38 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-283 | 07:18:40 | INTERRUPTED | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-395 | 07:57:30 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-396 | 07:57:31 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |

## strict-custom13

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-239 | 07:10:27 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-240 | 07:10:45 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01", "after": "ckyal-mac_fe6e4e55-c6e2-4dac-b1ee-01652a788a01"} |
| QA-241 | 07:10:46 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-242 | 07:10:46 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-243 | 07:10:46 | PASS | controller-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-244 | 07:10:46 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-245 | 07:10:46 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-246 | 07:10:46 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-247 | 07:10:46 | PASS | cainjector-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-248 | 07:10:46 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-249 | 07:10:46 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-250 | 07:10:46 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-251 | 07:10:46 | PASS | webhook-metrics TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-252 | 07:10:46 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-253 | 07:10:47 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-254 | 07:10:47 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-255 | 07:10:47 | PASS | cert-manager-webhook TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-256 | 07:10:47 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-257 | 07:10:47 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-258 | 07:10:47 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-259 | 07:10:47 | PASS | trust-manager-webhook TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-260 | 07:10:47 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-261 | 07:10:47 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-262 | 07:10:47 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-263 | 07:10:47 | FAIL | operator-existing TLS1.2 | reject | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-264 | 07:10:47 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-265 | 07:10:47 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-266 | 07:10:47 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-267 | 07:10:47 | PASS | operator-fresh TLS1.2 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-268 | 07:10:47 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-269 | 07:10:49 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14506} |
| QA-270 | 07:10:50 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-271 | 07:10:52 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92361} |
| QA-272 | 07:10:53 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-273 | 07:10:54 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56676} |
| QA-274 | 07:10:55 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-275 | 07:10:57 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-276 | 07:10:59 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-277 | 07:11:00 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:10:59 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-278 | 07:11:07 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:11:06Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 6, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:11:06Z", "revision": 6} |
| QA-279 | 07:11:11 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-280 | 07:11:12 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## strict-old

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-281 | 07:11:29 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-300 | 07:34:50 | PASS | platform operators settled | Assertion described by the check and README procedure holds | all Available=True, Progressing=False, Degraded=False |
| QA-301 | 07:35:02 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-302 | 07:35:31 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e", "after": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e"} |
| QA-303 | 07:35:32 | PASS | controller-metrics TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-304 | 07:35:32 | PASS | controller-metrics TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-305 | 07:35:32 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-306 | 07:35:32 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-307 | 07:35:32 | PASS | cainjector-metrics TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-308 | 07:35:32 | PASS | cainjector-metrics TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-309 | 07:35:32 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-310 | 07:35:32 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-311 | 07:35:32 | PASS | webhook-metrics TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-312 | 07:35:32 | PASS | webhook-metrics TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-313 | 07:35:32 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-314 | 07:35:32 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-315 | 07:35:33 | PASS | cert-manager-webhook TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-316 | 07:35:33 | PASS | cert-manager-webhook TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-ECDSA-AES128-SHA"} |
| QA-317 | 07:35:33 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-318 | 07:35:33 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-319 | 07:35:33 | PASS | trust-manager-webhook TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-RSA-AES128-SHA"} |
| QA-320 | 07:35:33 | PASS | trust-manager-webhook TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-RSA-AES128-SHA"} |
| QA-321 | 07:35:33 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-322 | 07:35:33 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-323 | 07:35:33 | FAIL | operator-existing TLS1.0 | accept | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-324 | 07:35:33 | FAIL | operator-existing TLS1.1 | accept | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-325 | 07:35:33 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-326 | 07:35:33 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-327 | 07:35:33 | PASS | operator-fresh TLS1.0 | accept | {"accepted": true, "protocol": "TLSv1", "cipher": "ECDHE-RSA-AES128-SHA"} |
| QA-328 | 07:35:33 | PASS | operator-fresh TLS1.1 | accept | {"accepted": true, "protocol": "TLSv1.1", "cipher": "ECDHE-RSA-AES128-SHA"} |
| QA-329 | 07:35:33 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-330 | 07:35:33 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-331 | 07:35:35 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14495} |
| QA-332 | 07:35:36 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-333 | 07:35:38 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92243} |
| QA-334 | 07:35:39 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-335 | 07:35:41 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56670} |
| QA-336 | 07:35:41 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-337 | 07:35:44 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-338 | 07:35:45 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-339 | 07:35:46 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:35:46 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-340 | 07:36:02 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:35:59Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 7, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:35:59Z", "revision": 7} |
| QA-341 | 07:36:06 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-342 | 07:36:07 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## admission

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-284 | 07:21:12 | PASS | API rejects unknown-profile | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: <br>* spec.tlsSecurityProfile.type: Unsupported value: "Nonexistent": supported values: "Old", "Intermediate", "Modern", "Custom"<br>* <nil>: Invalid value: null: some validation rules were not checked because the object was invalid; correct the existing errors to complete validation<br> |
| QA-285 | 07:21:13 | PASS | API rejects missing-custom | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: spec.tlsSecurityProfile.custom: Required value: type set to Custom, but the corresponding field is unset<br> |
| QA-286 | 07:21:14 | PASS | API rejects invalid-minimum | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: <br>* spec.tlsSecurityProfile.custom.minTLSVersion: Unsupported value: "TLS9": supported values: "VersionTLS10", "VersionTLS11", "VersionTLS12", "VersionTLS13"<br>* <nil>: Invalid value: null: some validation rules were not checked because the object was invalid; correct the existing errors to complete validation<br> |
| QA-287 | 07:21:15 | PASS | API rejects empty-cipher-list | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: <br>* spec.tlsSecurityProfile.custom.ciphers: Invalid value: []: no supported cipher suite found<br>* spec.tlsSecurityProfile.custom.ciphers: Invalid value: []: http2: TLSConfig.CipherSuites is missing an HTTP/2-required AES_128_GCM_SHA256 cipher (need at least one of ECDHE-RSA-AES128-GCM-SHA256 or ECDHE-ECDSA-AES128-GCM-SHA256)<br> |
| QA-288 | 07:21:16 | PASS | API rejects unknown-adherence | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: <br>* spec.tlsAdherence: Unsupported value: "Nonexistent": supported values: "LegacyAdheringComponentsOnly", "StrictAllComponents"<br>* <nil>: Invalid value: null: some validation rules were not checked because the object was invalid; correct the existing errors to complete validation<br> |
| QA-289 | 07:21:18 | PASS | API rejects configurable-tls13-ciphers | server-side dry run rejected; no mutation | The APIServer "cluster" is invalid: spec.tlsSecurityProfile.custom.ciphers: Invalid value: ["TLS_AES_128_GCM_SHA256"]: TLS 1.3 cipher suites are not configurable<br> |

## rbac-packaging

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-290 | 07:21:19 | PASS | new Role scopes updates to metrics CA | Assertion described by the check and README procedure holds | [{"apiGroups": [""], "resourceNames": ["cert-manager-metrics-ca"], "resources": ["secrets"], "verbs": ["get", "list", "watch", "update"]}, {"apiGroups": [""], "resources": ["secrets"], "verbs": ["create"]}] |
| QA-291 | 07:21:19 | PASS | RoleBinding covers all three service accounts | Assertion described by the check and README procedure holds | [{"kind": "ServiceAccount", "name": "cert-manager", "namespace": "cert-manager"}, {"kind": "ServiceAccount", "name": "cert-manager-webhook", "namespace": "cert-manager"}, {"kind": "ServiceAccount", "name": "cert-manager-cainjector", "namespace": "cert-manager"}] |
| QA-292 | 07:21:20 | PASS | baseline controller broad Secret access is pre-existing | Assertion described by the check and README procedure holds | [{"apiGroups": ["cert-manager.io"], "resources": ["certificates", "certificates/status", "certificaterequests", "certificaterequests/status"], "verbs": ["update", "patch"]}, {"apiGroups": ["cert-manager.io"], "resources": ["certificates", "certificaterequests", "clusterissuers", "issuers"], "verbs": ["get", "list", "watch"]}, {"apiGroups": ["cert-manager.io"], "resources": ["certificates/finalizers", "certificaterequests/finalizers"], "verbs": ["update"]}, {"apiGroups": ["acme.cert-manager.io"], "resources": ["orders"], "verbs": ["create", "delete", "get", "list", "watch"]}, {"apiGroups": [""], "resources": ["secrets"], "verbs": ["get", "list", "watch", "create", "update", "delete", "patch"]}, {"apiGroups": [""], "resources": ["events"], "verbs": ["create", "patch"]}] |
| QA-293 | 07:22:47 | PASS | role recreated after deletion | Assertion described by the check and README procedure holds | operator static-resource reconciliation |
| QA-294 | 07:22:59 | PASS | rolebinding recreated after deletion | Assertion described by the check and README procedure holds | operator static-resource reconciliation |
| QA-295 | 07:23:01 | PASS | operator metrics Service requests serving certificate | Assertion described by the check and README procedure holds | {"kubectl.kubernetes.io/last-applied-configuration": "{\"apiVersion\":\"v1\",\"kind\":\"Service\",\"metadata\":{\"annotations\":{\"service.beta.openshift.io/serving-cert-secret-name\":\"cert-manager-operator-serving-cert\"},\"labels\":{\"app.kubernetes.io/created-by\":\"cert-manager-operator\",\"app.kubernetes.io/instance\":\"controller-manager-metrics-service\",\"app.kubernetes.io/managed-by\":\"kustomize\",\"app.kubernetes.io/name\":\"service\",\"app.kubernetes.io/part-of\":\"cert-manager-operator\",\"control-plane\":\"controller-manager\"},\"name\":\"cert-manager-operator-controller-manager-metrics-service\",\"namespace\":\"cert-manager-operator\"},\"spec\":{\"ports\":[{\"name\":\"https\",\"port\":8443,\"protocol\":\"TCP\",\"targetPort\":\"https\"}],\"selector\":{\"control-plane\":\"controller-manager\"}}}\n", "service.alpha.openshift.io/serving-cert-signed-by": "openshift-service-serving-signer@1791179189", "service.beta.openshift.io/serving-cert-secret-name": "cert-manager-operator-serving-cert", "service.beta.openshift.io/serving-cert-signed-by": "openshift-service-serving-signer@1791179189"} |
| QA-296 | 07:23:01 | PASS | operator Deployment mounts optional serving Secret | Assertion described by the check and README procedure holds | {"volumes": [{"emptyDir": {}, "name": "tmp"}, {"name": "serving-cert", "secret": {"defaultMode": 420, "optional": true, "secretName": "cert-manager-operator-serving-cert"}}], "mounts": [{"mountPath": "/tmp", "name": "tmp"}, {"mountPath": "/var/run/secrets/serving-cert", "name": "serving-cert", "readOnly": true}], "replicas": 0} |
| QA-297 | 07:23:02 | PASS | service-ca issued operator DNS certificate | Assertion described by the check and README procedure holds | subject=CN=cert-manager-operator-controller-manager-metrics-service.cert-manager-operator.svc<br>issuer=CN=openshift-service-serving-signer@1791179189<br>notBefore=Oct  5 06:18:30 2026 GMT<br>notAfter=Oct  4 06:18:31 2028 GMT<br>X509v3 Subject Alternative Name: <br>    DNS:cert-manager-operator-controller-manager-metrics-service.cert-manager-operator.svc, DNS:cert-manager-operator-controller-manager-metrics-service.cert-manager-operator.svc.cluster.local<br> |
| QA-298 | 07:23:02 | PASS | CSV TLS feature claim bundle/manifests/cert-manager-operator.clusterserviceversion.yaml | Assertion described by the check and README procedure holds | ["features.operators.openshift.io/tls-profiles: \"true\""] |
| QA-299 | 07:23:02 | PASS | CSV TLS feature claim config/manifests/bases/cert-manager-operator.clusterserviceversion.yaml | Assertion described by the check and README procedure holds | ["features.operators.openshift.io/tls-profiles: \"true\""] |

## operator-metrics-auth

Raw [results](evidence/serving/results.jsonl) and [commands](evidence/serving/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-343 | 07:40:56 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e", "after": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e"} |
| QA-344 | 07:40:58 | PASS | operator metrics denies anonymous request | Assertion described by the check and README procedure holds | {"status": 403, "prometheus": false, "bytes": 192} |
| QA-345 | 07:40:58 | PASS | operator metrics permits authorized HTTPS scrape | Assertion described by the check and README procedure holds | {"status": 200, "prometheus": true, "bytes": 108835} |

## operator-service-ca

Raw [results](evidence/serving/results.jsonl) and [commands](evidence/serving/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-346 | 07:41:02 | PASS | OpenShift service CA bundle injected | Assertion described by the check and README procedure holds | test namespace ConfigMap |
| QA-347 | 07:41:08 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e", "after": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e"} |
| QA-348 | 07:41:08 | PASS | operator serves real service-ca certificate | TLS1.3; chain and Service DNS verified | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-349 | 07:41:08 | PASS | operator certificate rejects wrong DNS identity | Assertion described by the check and README procedure holds | {"accepted": false, "error": "[SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: Hostname mismatch, certificate is not valid for 'wrong.example.test'. (_ssl.c:1082)"} |

## monitoring

Raw [results](evidence/monitoring/results.jsonl) and [commands](evidence/monitoring/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-350 | 07:56:14 | PASS | platform operators settled | Assertion described by the check and README procedure holds | all Available=True, Progressing=False, Degraded=False |
| QA-391 | 07:57:11 | PASS | user-workload Prometheus starts | Assertion described by the check and README procedure holds | prometheus-user-workload-0 |
| QA-398 | 07:57:56 | PASS | platform available for testing | Assertion described by the check and README procedure holds | all Available=True, Degraded=False; two successful API samples, 15s apart; platform rollouts may continue |
| QA-400 | 08:01:47 | PASS | platform available for testing | Assertion described by the check and README procedure holds | all Available=True, Degraded=False; two successful API samples, 15s apart; platform rollouts may continue |
| QA-401 | 08:01:50 | PASS | user-workload Prometheus starts | Assertion described by the check and README procedure holds | prometheus-user-workload-0 |
| QA-403 | 08:02:05 | PASS | documented HTTP ServiceMonitor fails on HTTPS metrics | three HTTP 400 targets reproduce documentation regression | [{"url": "http://10.128.2.24:9402/metrics", "health": "down", "error": "server returned HTTP status 400 Bad Request"}, {"url": "http://10.131.0.27:9402/metrics", "health": "down", "error": "server returned HTTP status 400 Bad Request"}, {"url": "http://10.131.0.22:9402/metrics", "health": "down", "error": "server returned HTTP status 400 Bad Request"}] |
| QA-410 | 08:03:13 | PASS | CA-verified HTTPS ServiceMonitors scrape all operands | all three targets UP with CA and DNS verification | [{"url": "https://10.128.2.27:9402/metrics", "health": "up", "error": ""}, {"url": "https://10.128.2.26:9402/metrics", "health": "up", "error": ""}, {"url": "https://10.128.2.28:9402/metrics", "health": "up", "error": ""}] |
| QA-412 | 08:03:18 | PASS | restore original monitoring configuration | Assertion described by the check and README procedure holds | ConfigMap data equals original |

## legacy-modern

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-351 | 07:56:14 | PASS | platform operators settled | Assertion described by the check and README procedure holds | all Available=True, Progressing=False, Degraded=False |
| QA-352 | 07:56:31 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-353 | 07:56:49 | PASS | follower preserves existing leader | Assertion described by the check and README procedure holds | {"before": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e", "after": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e"} |
| QA-354 | 07:56:50 | PASS | controller-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-355 | 07:56:50 | PASS | controller-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-356 | 07:56:51 | PASS | controller-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-357 | 07:56:51 | PASS | controller-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-358 | 07:56:51 | PASS | cainjector-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-359 | 07:56:51 | PASS | cainjector-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-360 | 07:56:51 | PASS | cainjector-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-361 | 07:56:51 | PASS | cainjector-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-362 | 07:56:51 | PASS | webhook-metrics TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-363 | 07:56:51 | PASS | webhook-metrics TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-364 | 07:56:51 | PASS | webhook-metrics TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-365 | 07:56:51 | PASS | webhook-metrics TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-366 | 07:56:51 | PASS | cert-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-367 | 07:56:51 | PASS | cert-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-368 | 07:56:52 | PASS | cert-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256"} |
| QA-369 | 07:56:52 | PASS | cert-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-370 | 07:56:52 | PASS | trust-manager-webhook TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-371 | 07:56:52 | PASS | trust-manager-webhook TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-372 | 07:56:52 | PASS | trust-manager-webhook TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-373 | 07:56:52 | PASS | trust-manager-webhook TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-374 | 07:56:52 | PASS | operator-existing TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-375 | 07:56:52 | PASS | operator-existing TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-376 | 07:56:52 | PASS | operator-existing TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-377 | 07:56:52 | PASS | operator-existing TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-378 | 07:56:52 | PASS | operator-fresh TLS1.0 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-379 | 07:56:52 | PASS | operator-fresh TLS1.1 | reject | {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"} |
| QA-380 | 07:56:52 | PASS | operator-fresh TLS1.2 | accept | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-381 | 07:56:52 | PASS | operator-fresh TLS1.3 | accept | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-382 | 07:56:54 | PASS | controller-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 14496} |
| QA-383 | 07:56:55 | PASS | controller-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-384 | 07:56:57 | PASS | cainjector-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 92169} |
| QA-385 | 07:56:58 | PASS | cainjector-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-386 | 07:56:59 | PASS | webhook-metrics trusted HTTPS scrape | CA and DNS verification; HTTP 200; Prometheus text | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "status": "HTTP/1.1 200 OK", "prometheus": true, "bytes": 56685} |
| QA-387 | 07:57:00 | PASS | webhook-metrics rejects plaintext scrape | HTTP 400 or connection rejection | HTTP/1.0 400 Bad Request<br><br>Client sent an HTTP request to an HTTPS server.<br> |
| QA-388 | 07:57:02 | PASS | trust-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-389 | 07:57:04 | PASS | cert-manager-webhook CA/SAN validation | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-390 | 07:57:05 | PASS | trust-manager metrics retain HTTP | HTTP remains supported; outside PR TLS scope | HTTP/1.1 200 OK<br>Content-Type: text/plain; version=0.0.4; charset=utf-8; escaping=underscores<br>Date: Mon, 05 Oct 2026 07:57:04 GMT<br>Connection: close<br>Transfer-Encoding: chunked<br> |
| QA-392 | 07:57:18 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T07:57:17Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 8, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T07:57:17Z", "revision": 8} |
| QA-393 | 07:57:22 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-394 | 07:57:23 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## extended-current-old

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-397 | 07:57:55 | PASS | platform available for testing | Assertion described by the check and README procedure holds | all Available=True, Degraded=False; two successful API samples, 15s apart; platform rollouts may continue |

## extended-default

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-399 | 08:01:46 | PASS | platform available for testing | Assertion described by the check and README procedure holds | all Available=True, Degraded=False; two successful API samples, 15s apart; platform rollouts may continue |
| QA-402 | 08:01:58 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |

## stability-drift

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-404 | 08:02:21 | PASS | unrelated APIServer annotation causes no rollouts | Assertion described by the check and README procedure holds | {"cert-manager": 13, "cert-manager-cainjector": 13, "cert-manager-webhook": 13, "trust-manager": 13} |
| QA-405 | 08:02:25 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-406 | 08:02:25 | PASS | SSA repairs altered trust-manager TLS minimum | Assertion described by the check and README procedure holds | expected TLS1.2 restored after direct Deployment mutation |
| QA-407 | 08:02:57 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-408 | 08:02:57 | PASS | operand pod restart retains TLS configuration | Assertion described by the check and README procedure holds | all old pod UIDs replaced; rollout converged |
| QA-409 | 08:02:59 | PASS | shared metrics CA survives operand restarts | Assertion described by the check and README procedure holds | current public CA equals the baseline source ConfigMap certificate |
| QA-411 | 08:03:17 | PASS | controller-metrics TLS after pod restart | Assertion described by the check and README procedure holds | {"lower TLS1.1": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "minimum TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256", "certificate_sha256": "5b304e749421b901c1e283657f504cd87ecc9728117399e6e93a180010f79179"}, "TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "5b304e749421b901c1e283657f504cd87ecc9728117399e6e93a180010f79179"}} |
| QA-413 | 08:03:20 | PASS | cainjector-metrics TLS after pod restart | Assertion described by the check and README procedure holds | {"lower TLS1.1": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "minimum TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256", "certificate_sha256": "85c23e7abd35ede5fdd72542430da92b609110da59e586523879ed2e15e8843c"}, "TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "85c23e7abd35ede5fdd72542430da92b609110da59e586523879ed2e15e8843c"}} |
| QA-414 | 08:03:23 | PASS | webhook-metrics TLS after pod restart | Assertion described by the check and README procedure holds | {"lower TLS1.1": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "minimum TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256", "certificate_sha256": "31a1de2715dbe528b3ac55622ffbd153e66be4e579d0dca3d8e2bbae78c7d827"}, "TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "31a1de2715dbe528b3ac55622ffbd153e66be4e579d0dca3d8e2bbae78c7d827"}} |
| QA-415 | 08:03:26 | PASS | cert-manager-webhook TLS after pod restart | Assertion described by the check and README procedure holds | {"lower TLS1.1": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "minimum TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-ECDSA-AES128-GCM-SHA256", "certificate_sha256": "e58272e4ca5335e38b02ef03ccfa2f51b9831e2cfe5cb5ca92b00cac610c0e21"}, "TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "e58272e4ca5335e38b02ef03ccfa2f51b9831e2cfe5cb5ca92b00cac610c0e21"}} |
| QA-416 | 08:03:29 | PASS | trust-manager-webhook TLS after pod restart | Assertion described by the check and README procedure holds | {"lower TLS1.1": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "minimum TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256", "certificate_sha256": "8f92e8b3ef2d9840e2214dc97fac3c9dd5b310b0e62106d95ec4a76de6f96098"}, "TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "8f92e8b3ef2d9840e2214dc97fac3c9dd5b310b0e62106d95ec4a76de6f96098"}} |
| QA-417 | 08:03:39 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T08:03:38Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 9, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T08:03:38Z", "revision": 9} |
| QA-418 | 08:03:42 | PASS | Existing Bundle Synced and target present | Synced=True and PEM in target; per-profile spec was unchanged; fresh generation and exact CA contents verified separately in final-functional | bundle.trust.cert-manager.io/cmo-pr466-qa condition met<br> |
| QA-419 | 08:03:43 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## override-precedence

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-420 | 08:03:50 | PASS | unsupported controller override takes precedence | Assertion described by the check and README procedure holds | ["--acme-http01-solver-image=quay.io/jetstack/cert-manager-acmesolver:v1.20.3", "--cluster-resource-namespace=$(POD_NAMESPACE)", "--feature-gates=ACMEHTTP01IngressPathTypeExact=false", "--leader-election-namespace=kube-system", "--max-concurrent-challenges=60", "--metrics-dynamic-serving-ca-secret-name=cert-manager-metrics-ca", "--metrics-dynamic-serving-ca-secret-namespace=$(POD_NAMESPACE)", "--metrics-dynamic-serving-dns-names=cert-manager,cert-manager.$(POD_NAMESPACE),cert-manager.$(POD_NAMESPACE).svc", "--metrics-tls-cipher-suites=TLS_AES_128_GCM_SHA256,TLS_AES_256_GCM_SHA384,TLS_CHACHA20_POLY1305_SHA256,TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256,TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384,TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256,TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256", "--metrics-tls-min-version=VersionTLS13", "--v=2"] |
| QA-421 | 08:04:09 | PASS | override affects actual metrics listener only | Assertion described by the check and README procedure holds | {"controller TLS1.3": {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256", "certificate_sha256": "5caf02f6c92724ea730386d896c4be9002082b07d9f68e26449eccf71515a054"}, "controller TLS1.2": {"accepted": false, "error": "[SSL: TLSV1_ALERT_PROTOCOL_VERSION] tlsv1 alert protocol version (_ssl.c:1082)"}, "trust-manager TLS1.2": {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256", "certificate_sha256": "8f92e8b3ef2d9840e2214dc97fac3c9dd5b310b0e62106d95ec4a76de6f96098"}} |
| QA-422 | 08:04:16 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |

## extended-restore

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-423 | 08:04:18 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-424 | 08:04:29 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |

## final-functional

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-425 | 08:15:48 | PASS | certificate admission and issuance/reissuance | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T08:15:48Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 10, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T08:15:48Z", "revision": 10} |
| QA-426 | 08:15:53 | PASS | Bundle current-generation admission and exact CA distribution | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:57:44Z", "message": "Successfully synced Bundle to namespaces that match this label selector: cmo-pr466-qa=true", "observedGeneration": 2, "reason": "Synced", "status": "True", "type": "Synced"}]} |
| QA-427 | 08:15:53 | PASS | trust-manager serving Certificate Ready | Assertion described by the check and README procedure holds | {"conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "message": "Certificate is up to date and has not expired", "observedGeneration": 1, "reason": "Ready", "status": "True", "type": "Ready"}], "notAfter": "2027-01-03T06:50:00Z", "revision": 1} |

## cleanup

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-428 | 08:16:56 | PASS | restore original effective APIServer TLS behavior | original profile; explicit Legacy because removal is forbidden by OpenShift CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-429 | 08:17:00 | PASS | deployment arguments and rollout | Assertion described by the check and README procedure holds | Expected minimum/cipher flags, dynamic HTTPS arguments, no duplicate flags, and completed rollouts. Full arguments in results.jsonl and phase deployment snapshot. |
| QA-430 | 08:18:22 | PASS | platform operators settled | Assertion described by the check and README procedure holds | all Available=True, Degraded=False; Progressing=False |

## final-validation

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-431 | 08:31:11 | PASS | all nodes, machine pools and platform operators recovered | two samples: nodes Ready/schedulable, pools Updated/nondegraded, operators Available/nonprogressing/nondegraded | {"pending": [], "healthy_samples": 2} |
| QA-432 | 08:31:16 | PASS | APIServer effective baseline restored | original spec plus explicit Legacy adherence required by CEL | {"audit": {"profile": "Default"}, "tlsAdherence": "LegacyAdheringComponentsOnly"} |
| QA-433 | 08:31:16 | PASS | QA APIServer annotation removed | Assertion described by the check and README procedure holds | annotation absent |
| QA-434 | 08:31:17 | RESTORED | CertManager original spec restored | Assertion described by the check and README procedure holds | {"original_observation": {"logLevel": "Normal", "managementState": "Managed", "observedConfig": null, "operatorLogLevel": "Normal"}, "qualification": "The merge-patch rollback removed an originally explicit null unsupportedConfigOverrides field. Effective behavior was unchanged; the exact original spec was restored with JSON Patch and verified in final-exact-restore."} |
| QA-435 | 08:31:18 | PASS | TrustManager spec preserved and Ready | Assertion described by the check and README procedure holds | {"conditions": {"Degraded": "False", "Ready": "True"}} |
| QA-436 | 08:31:18 | PASS | all four operand Deployments ready | Assertion described by the check and README procedure holds | {"cert-manager": {"availableReplicas": 1, "conditions": [{"lastTransitionTime": "2026-10-05T06:45:13Z", "lastUpdateTime": "2026-10-05T08:04:21Z", "message": "ReplicaSet \"cert-manager-57f5d867cb\" has successfully progressed.", "reason": "NewReplicaSetAvailable", "status": "True", "type": "Progressing"}, {"lastTransitionTime": "2026-10-05T08:10:44Z", "lastUpdateTime": "2026-10-05T08:10:44Z", "message": "Deployment has minimum availability.", "reason": "MinimumReplicasAvailable", "status": "True", "type": "Available"}], "observedGeneration": 16, "readyReplicas": 1, "replicas": 1, "terminatingReplicas": 0, "updatedReplicas": 1}, "cert-manager-cainjector": {"availableReplicas": 1, "conditions": [{"lastTransitionTime": "2026-10-05T06:45:13Z", "lastUpdateTime": "2026-10-05T08:04:20Z", "message": "ReplicaSet \"cert-manager-cainjector-5486cc474c\" has successfully progressed.", "reason": "NewReplicaSetAvailable", "status": "True", "type": "Progressing"}, {"lastTransitionTime": "2026-10-05T08:06:37Z", "lastUpdateTime": "2026-10-05T08:06:37Z", "message": "Deployment has minimum availability.", "reason": "MinimumReplicasAvailable", "status": "True", "type": "Available"}], "observedGeneration": 14, "readyReplicas": 1, "replicas": 1, "terminatingReplicas": 0, "updatedReplicas": 1}, "cert-manager-webhook": {"availableReplicas": 1, "conditions": [{"lastTransitionTime": "2026-10-05T06:45:12Z", "lastUpdateTime": "2026-10-05T08:04:26Z", "message": "ReplicaSet \"cert-manager-webhook-6474b94467\" has successfully progressed.", "reason": "NewReplicaSetAvailable", "status": "True", "type": "Progressing"}, {"lastTransitionTime": "2026-10-05T08:06:37Z", "lastUpdateTime": "2026-10-05T08:06:37Z", "message": "Deployment has minimum availability.", "reason": "MinimumReplicasAvailable", "status": "True", "type": "Available"}], "observedGeneration": 14, "readyReplicas": 1, "replicas": 1, "terminatingReplicas": 0, "updatedReplicas": 1}, "trust-manager": {"availableReplicas": 1, "conditions": [{"lastTransitionTime": "2026-10-05T06:50:00Z", "lastUpdateTime": "2026-10-05T08:04:27Z", "message": "ReplicaSet \"trust-manager-7df4f9564\" has successfully progressed.", "reason": "NewReplicaSetAvailable", "status": "True", "type": "Progressing"}, {"lastTransitionTime": "2026-10-05T08:10:54Z", "lastUpdateTime": "2026-10-05T08:10:54Z", "message": "Deployment has minimum availability.", "reason": "MinimumReplicasAvailable", "status": "True", "type": "Available"}], "observedGeneration": 16, "readyReplicas": 1, "replicas": 1, "terminatingReplicas": 0, "updatedReplicas": 1}} |
| QA-437 | 08:31:18 | PASS | QA bundle/cmo-pr466-qa removed | Assertion described by the check and README procedure holds | absent |
| QA-438 | 08:31:19 | PASS | QA namespace/cmo-pr466-qa removed | Assertion described by the check and README procedure holds | absent |
| QA-439 | 08:31:20 | PASS | QA configmap/cmo-pr466-source removed | Assertion described by the check and README procedure holds | absent |
| QA-440 | 08:31:21 | PASS | QA clusterrole/cmo-pr466-qa-metrics removed | Assertion described by the check and README procedure holds | absent |
| QA-441 | 08:31:22 | PASS | QA clusterrolebinding/cmo-pr466-qa-metrics removed | Assertion described by the check and README procedure holds | absent |
| QA-442 | 08:31:23 | PASS | QA ServiceMonitors removed | Assertion described by the check and README procedure holds | [] |
| QA-443 | 08:31:23 | PASS | monitoring ConfigMap data restored exactly | Assertion described by the check and README procedure holds | data equals original |
| QA-444 | 08:31:24 | PASS | temporary user-workload monitoring pods removed | Assertion described by the check and README procedure holds | [] |
| QA-445 | 08:31:25 | PASS | restarted local operator remains active leader | Assertion described by the check and README procedure holds | {"pid": 63021, "running": true, "holderIdentity": "ckyal-mac_48351988-8f8c-48bb-816b-91b359123d8e", "lease_age_seconds": 17.535599} |
| QA-446 | 08:31:25 | PASS | final operator metrics accepts TLS1.2 | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.2", "cipher": "ECDHE-RSA-AES128-GCM-SHA256"} |
| QA-447 | 08:31:25 | PASS | final operator metrics accepts TLS1.3 | Assertion described by the check and README procedure holds | {"accepted": true, "protocol": "TLSv1.3", "cipher": "TLS_AES_128_GCM_SHA256"} |
| QA-448 | 08:31:25 | PASS | QA followers and port-forwards stopped | Assertion described by the check and README procedure holds | {"still_listening": []} |

## final-exact-restore

Raw [results](evidence/results.jsonl) and [commands](evidence/commands.log).

| ID | Time (UTC) | Result | Check | Expected | Observed |
|---|---|---|---|---|---|
| QA-449 | 08:33:57 | PASS | CertManager exact original spec restored | including the originally explicit null unsupportedConfigOverrides field | {"logLevel": "Normal", "managementState": "Managed", "observedConfig": null, "operatorLogLevel": "Normal", "unsupportedConfigOverrides": null} |

