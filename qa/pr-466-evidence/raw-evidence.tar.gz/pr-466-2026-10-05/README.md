# PR #466 live quality assessment — 2026-10-05

PR: [CM-1225: Apply cluster TLS profile to trust-manager, operator metrics, and operand HTTPS metrics](https://github.com/openshift/cert-manager-operator/pull/466).

This directory contains live test evidence, reproducible checks, and the assessment in `REPORT.md`. No production implementation was changed.

## Environment and scope

- Repository/PR HEAD: `b116f756e5333645814aeabfc0569933111bc5be`; branch `trustmanager_tls_impl`.
- OpenShift: `5.0.0-0.nightly-2026-09-29-171841`, GCP cluster `ci-ln-605hqdt-72292`.
- Operator runs locally; the in-cluster operator Deployment is scaled to zero.
- Local binary: Go 1.26.0, macOS arm64, built from the same HEAD with existing dirty worktree changes. The pre-existing Makefile and console-resource changes are recorded in `evidence/pre-existing-local-changes.patch` and were preserved.
- cert-manager controller/webhook/cainjector: upstream `quay.io/jetstack/*:v1.20.3`.
- trust-manager: `quay.io/jetstack/trust-manager:v0.20.3`.
- Tools: `oc`, Python 3.14.7 `ssl`, OpenSSL 3.6.4, Go 1.26.0.
- This tests the supplied local-development installation. It does not establish OLM upgrade/install behavior or compliance of Red Hat production/FIPS operand images.

## Evidence map

| File | Contents |
|---|---|
| `REPORT.md` | Findings, scenario results, cleanup, and coverage limits |
| `CHECKS.md` | Individual assertions, expected/observed results, timestamps |
| `evidence/commands.log` and `evidence/{serving,monitoring}/commands.log` | Exact `oc`/operator/OpenSSL invocations, input manifests, stdout/stderr, exit codes |
| `evidence/results.jsonl` and stage subdirectory `results.jsonl` files | Machine-readable assertion results |
| `evidence/*-handshakes.json` | TLS versions, negotiated ciphers, certificate fingerprints, handshake failures |
| `evidence/*-deployments.json` | Actual container arguments and rollout status for each profile |
| `evidence/baseline.json`, `evidence/final.json` | Cluster/operator state before and after testing |
| `evidence/final-platform.json`, `evidence/final-verification-time.json` | Final node, machine-pool, platform health and verification time |
| `evidence/final-certmanager-exact-restore.json` | Later exact CertManager spec restoration, preserving the original explicit null override field |
| `evidence/original-apiserver.json` | Original APIServer configuration for restoration |
| `evidence/*-operator-follower.log` | Startup/serving logs from temporary operator processes |
| `evidence/unit-tests.log` | Focused unit-suite results |

Only public certificate fields are collected. Kubeconfig contents, bearer tokens, Secret private keys, and full Secret objects are excluded from the report/evidence.

## Test method

The checks were executed against the live cluster and captured with small Python drivers to make the manual protocol checks repeatable. The primary pass/fail evidence is actual TLS handshakes, CA/SAN verification, HTTP responses, and resource functionality, supplemented by argument inspection and unit tests.

Each profile stage performs these steps:

1. Check platform availability, then replace the complete `spec.tlsSecurityProfile` union and set `spec.tlsAdherence` using a JSON patch. After rapid early transitions caused overlapping rollouts and transient API timeouts/429 responses, a platform guard was added. The final runner requires two successful API/availability samples 15 seconds apart between stages; complete platform, node and machine-pool convergence is checked during final cleanup. Old/Legacy retries also waited for complete platform convergence before testing.
2. Wait for all four operand Deployments to converge to their expected minimum-version/cipher flags and a completed rollout; verify HTTPS annotations and dynamic-serving arguments remain present and flags are not duplicated.
3. Select Ready, non-terminating pods whose arguments match their desired Deployment and start temporary port-forwards.
4. Start a second local operator process on `127.0.0.1:28443`, sharing the existing leader-election lock. Verify the existing leader retains the lock. This exercises the PR's real startup code without restarting the user's operator.
5. Probe exactly TLS 1.0, 1.1, 1.2, and 1.3 on every endpoint below. A successful handshake records the negotiated version, cipher, and peer certificate fingerprint; a rejection records the TLS error.
6. Scrape all three metrics endpoints with certificate chain and service DNS verification. Require HTTP 200 and Prometheus HELP/TYPE text. Also attempt plaintext HTTP, which must be rejected.
7. Verify both webhook certificate chains and DNS names. Confirm trust-manager metrics retain their existing plaintext HTTP behavior, outside the PR's webhook TLS scope.
8. Issue/reissue a test Certificate through the admission webhook and wait for `Ready=True` with the current generation. Create a Bundle using a test CA ConfigMap at baseline; in the executed profile matrix, verify that the existing Bundle stays `Synced=True` and its target remains populated. Verify the trust-manager serving Certificate remains Ready. The final functional stage changes the Bundle target key, checks `observedGeneration`, and compares source/target DER certificate fingerprints. The saved runner now uses that stronger generation check for future profile runs too; historical evidence is not presented as if it used the improved check.
9. Stop only the temporary followers/port-forwards and save a cluster snapshot.

The Custom TLS 1.2 stage additionally offers only allowed AES128-GCM ciphers, then only excluded AES256-GCM ciphers, on each listener. The negative probes retain a positive control to distinguish server policy enforcement from an unavailable endpoint.

| Endpoint | Pod port | Local test port | Certificate DNS identity |
|---|---:|---:|---|
| Controller metrics | 9402 | 19402 | `cert-manager.cert-manager.svc` |
| Cainjector metrics | 9402 | 19403 | `cert-manager-cainjector.cert-manager.svc` |
| Cert-manager webhook metrics | 9402 | 19404 | `cert-manager-webhook.cert-manager.svc` |
| Cert-manager admission webhook | 10250 | 19443 | `cert-manager-webhook.cert-manager.svc` |
| Trust-manager admission webhook | 6443 | 19444 | `trust-manager.cert-manager.svc` |
| Trust-manager metrics (HTTP control) | 9402 | 19405 | Not applicable |
| Original operator metrics | local 8443 | 8443 | Locally generated serving certificate |
| Fresh operator follower metrics | local 28443 | 28443 | Locally generated serving certificate |

## Profile matrix and manual commands

Set the supplied kubeconfig in the shell. The runners pass it explicitly because it was not exported in the agent's environment.

```sh
export KUBECONFIG="$PWD/cluster-bot-2026-10-05-051927.kubeconfig"
oc get apiserver cluster -o json > /tmp/pr466-apiserver-before.json
oc get certmanager,trustmanager -o yaml
oc get deploy,pods,svc -n cert-manager
```

**Cluster API constraint discovered during this run:** `tlsAdherence` cannot be removed once set. The original object omitted it; restoration must leave explicit `LegacyAdheringComponentsOnly`, which has the same current effective behavior. Do not promise byte-for-byte spec restoration when starting with this field absent. The failed removal attempts and successful equivalent restoration are preserved in the evidence.

| Stage | Adherence | Profile | Expected operand/fresh-operator protocols |
|---|---|---|---|
| Baseline | Initially absent | Absent | TLS 1.2 and 1.3 |
| Strict default | StrictAllComponents | Absent | TLS 1.2 and 1.3; Intermediate defaults |
| Strict Intermediate | StrictAllComponents | Intermediate | TLS 1.2 and 1.3 |
| Strict Modern | StrictAllComponents | Modern | TLS 1.3 only; operand cipher flags absent |
| Strict Custom 1.2 | StrictAllComponents | AES128-GCM ECDHE RSA/ECDSA; minimum 1.2 | TLS 1.2 with listed ciphers; TLS 1.3 allowed |
| Strict Custom 1.3 | StrictAllComponents | Minimum 1.3; empty cipher list | TLS 1.3 only; operand cipher flags absent; Go controls TLS 1.3 suites |
| Strict Old | StrictAllComponents | Old | TLS 1.0–1.3 where supported by the runtime |
| Legacy Modern | LegacyAdheringComponentsOnly | Modern | Component defaults: TLS 1.2 and 1.3; cluster-derived flags removed |

For example, apply Modern atomically:

```sh
oc patch apiserver cluster --type=json -p='[
  {"op":"add","path":"/spec/tlsAdherence","value":"StrictAllComponents"},
  {"op":"add","path":"/spec/tlsSecurityProfile","value":{"type":"Modern","modern":{}}}
]'
oc get deploy -n cert-manager -o json
oc rollout status deployment/trust-manager -n cert-manager --timeout=180s
```

Use the same patch with these complete profile values for the other stages:

```json
null
{"type":"Intermediate","intermediate":{}}
{"type":"Old","old":{}}
{"type":"Custom","custom":{"minTLSVersion":"VersionTLS12","ciphers":["ECDHE-ECDSA-AES128-GCM-SHA256","ECDHE-RSA-AES128-GCM-SHA256"]}}
{"type":"Custom","custom":{"minTLSVersion":"VersionTLS13","ciphers":[]}}
```

OpenShift requires an empty cipher list when the Custom minimum is 1.3; it rejects a nonempty list with `TLS 1.3 cipher suites are not configurable`. The rejected attempts and the corrected test are recorded. TLS 1.3 suite selection is controlled by Go, and the operand cipher arguments must be absent.

In a separate shell, forward a current Ready pod (the runner does this selection automatically):

```sh
oc port-forward -n cert-manager pod/<ready-current-controller-pod> 19402:9402
```

Representative independent protocol and scrape commands:

```sh
openssl s_client -connect 127.0.0.1:19402 -tls1_2 -brief </dev/null
openssl s_client -connect 127.0.0.1:19402 -tls1_3 -brief </dev/null
openssl s_client -connect 127.0.0.1:19402 -tls1_2 \
  -cipher ECDHE-ECDSA-AES256-GCM-SHA384 -brief </dev/null
curl -v http://127.0.0.1:19402/metrics
oc get secret cert-manager-metrics-ca -n cert-manager \
  -o jsonpath='{.data.tls\.crt}' | base64 -d > /tmp/pr466-metrics-ca.crt
curl --noproxy '*' --cacert /tmp/pr466-metrics-ca.crt \
  --resolve cert-manager.cert-manager.svc:19402:127.0.0.1 \
  https://cert-manager.cert-manager.svc:19402/metrics
```

Python `ssl` supplied the executed protocol probes recorded in `results.jsonl`; the OpenSSL/curl commands above are equivalent manual reproductions. TLS 1.0/1.1 clients may need `@SECLEVEL=0`; the driver sets this explicitly so the client does not reject those protocols before the server can respond.

## Running the captured checks again

These commands modify the selected live cluster. Run sequentially from the repository root against an isolated test cluster. The original local operator must remain running and hold its leader-election lock. Do not run multiple profile drivers concurrently.

```sh
python3 qa/pr-466-2026-10-05/live_check.py baseline
python3 qa/pr-466-2026-10-05/live_check.py profiles
python3 qa/pr-466-2026-10-05/extended_check.py preflight
python3 qa/pr-466-2026-10-05/extended_check.py serving
python3 qa/pr-466-2026-10-05/extended_check.py default
python3 qa/pr-466-2026-10-05/monitoring_check.py
python3 qa/pr-466-2026-10-05/live_check.py functional
python3 qa/pr-466-2026-10-05/live_check.py cleanup
python3 qa/pr-466-2026-10-05/final_check.py
python3 qa/pr-466-2026-10-05/render_checks.py
```

To preserve this run's evidence, copy the drivers to a new dated directory with a fresh evidence directory before another baseline run; update the hardcoded kubeconfig path for that test cluster. Do not reuse this run's original-object backups against another cluster. `baseline` saves originals; profile stages restore the original profile and effective adherence in `finally`. These scripts are a captured test recipe, not a general-purpose production automation tool. Review the terminal assertions: the drivers record failures and continue collecting evidence, so a zero process exit alone is not a passing assessment.

Emergency equivalent restoration for this specific run:

```sh
oc patch apiserver cluster --type=merge -p='{"spec":{
  "tlsAdherence":"LegacyAdheringComponentsOnly",
  "tlsSecurityProfile":null
}}'
```

## Additional checks and their steps

`extended_check.py` records the exact commands and results for the following scenarios:

1. Submit malformed profile/adherence values using **server-side dry-run**; record API acceptance/rejection without storing malformed cluster configuration.
2. Inspect metrics Role resourceNames and all three RoleBinding subjects. Check aggregate ServiceAccount permissions, accounting for the main controller's pre-existing permission to manage certificate Secrets.
3. Remove only the operator-owned metrics Role and RoleBinding, one at a time; wait for recreation and restore from captured definitions if reconciliation fails.
4. Inspect the operator metrics Service's serving-cert annotation, optional read-only Secret mount, issued certificate identity, and both source/bundle CSV TLS feature claims.
5. Under Strict with the profile absent (Intermediate default), annotate the APIServer with an unrelated test annotation; compare Deployment generations and remove the annotation.
6. Change the trust-manager Deployment's TLS minimum directly to 1.3; require the SSA controller to restore 1.2.
7. Restart operand pods and verify new UIDs, completed rollouts, TLS 1.1 rejection/TLS 1.2 and 1.3 acceptance, fresh Certificate readiness, and the existing Bundle target. Compare the metrics CA before and after the restarts.
8. Set the main controller's unsupported metrics TLS override to 1.3 under Strict default/Intermediate; require its metrics listener to reject TLS 1.2 while trust-manager still accepts TLS 1.2. Restore the original CertManager override afterward.
9. Create a temporary ServiceAccount with `/metrics` GET permission, start a follower, and check anonymous denial and an authorized HTTPS scrape. The short-lived token is held in memory and never logged. Remove the temporary cluster RBAC afterward. This independent check ran on port 38443 under the active Old profile while the platform settled; it does not mutate TLS policy.
10. Inject the OpenShift service CA into a test ConfigMap, load the actual operator serving certificate into a follower through an explicit temporary serving configuration, and validate its chain and Service DNS name over TLS. Reject an incorrect DNS name. Private key material stays in a permission-restricted temporary directory and is removed afterward. This does not replace a packaged in-cluster mount/rotation test.

Focused unit validation was also executed:

```sh
go test -count=1 ./pkg/tlsprofile ./pkg/controller/common \
  ./pkg/controller/trustmanager ./pkg/controller/certmanager ./pkg/cmd/operator
```

All four packages with tests passed; `pkg/cmd/operator` has no test files. Unit coverage supplements live testing for invalid/missing profile data, APIServer fetch failures, missing containers, argument merging, TLS 1.3 cipher stripping, and event predicates.

## End-to-end monitoring procedure

`monitoring_check.py` temporarily enables OpenShift user-workload monitoring while preserving the existing `cluster-monitoring-config` data. After Prometheus is Ready, it:

1. Creates a ServiceMonitor equivalent to the documentation's HTTP example (with a shorter test scrape interval).
2. Reads Prometheus `/api/v1/targets` through a pod port-forward and requires three DOWN targets reporting HTTP 400, reproducing the missing-HTTPS configuration issue.
3. Replaces that test monitor with three component-specific HTTPS ServiceMonitors. Each references the public CA in `cert-manager-metrics-ca` and supplies the correct service DNS identity through `tlsConfig.serverName`; it does not disable certificate verification.
4. Requires all three targets to become UP with empty last-error fields.
5. Removes its ServiceMonitors and restores the exact original monitoring ConfigMap data, using a JSON-patch test operation to avoid overwriting concurrent changes.

See `evidence/monitoring/monitoring-{http,https}-targets.json` for actual scrape URLs, timestamps, health, and errors. The executed monitor manifests appear in `evidence/monitoring/commands.log`.

Result: at 08:02:05 UTC all three HTTP targets were DOWN with HTTP 400; at 08:03:13 UTC all three CA-verified HTTPS targets were UP with no scrape errors. Original monitoring data was restored at 08:03:18 UTC. The reusable [HTTPS ServiceMonitor manifest](https-servicemonitors.json) contains the three tested monitor definitions; it is a QA artifact and is not installed after cleanup.

## Execution/recovery notes

- The initial port-forward helper selected a Pending trust-manager pod. It was corrected to pin current Ready pods; interrupted stages were retried.
- The original APIServer omitted `tlsAdherence`. Its CEL rule prevented removing the field after testing; cleanup uses explicit Legacy adherence and removes the profile. It does not delete/recreate the APIServer object or bypass validation.
- Two initial Custom TLS 1.3 payloads with nonempty cipher lists were rejected by the cluster; the corrected payload uses an empty list.
- Rapid early TLS transitions triggered overlapping platform rollouts and transient API timeouts/429 responses. The original local operator later exited during that interval. Its stdout was not available to prove the exact exit reason. The test runner's rollback wait timed out while no local leader was reconciling.
- The existing binary was restarted with the Makefile's image/version settings and TrustManager enabled. Both `--kubeconfig` and the `KUBECONFIG` environment variable are required in this local setup: library-go uses the flag, while controller-runtime consults the environment. An initial restart omitted the environment variable and exited; the corrected restart uses it explicitly.
- The restarted leader is intentionally left running for the user. Its PID/command are in `evidence/restarted-local-operator.json`, and logs are in `evidence/restarted-local-operator.log`. The temporary test followers are stopped.
- One monitoring driver was interrupted during its initial target wait. Before resuming, its original ConfigMap backup was recovered from the first recorded GET; the final driver preserves that backup and refuses unrelated concurrent changes. The resumed HTTP and HTTPS scrape stages completed, and exact original ConfigMap data restoration passed.
- Profile changes affect shared OpenShift components and trigger machine configuration/node rollouts as well as operand rollouts. Final recovery is checked independently of feature assertions. No manual node uncordon, platform operator patch, or static-pod revision edit was used to force a green result.
- Final platform and cleanup verification completed at 08:31:25 UTC. A final exact-spec comparison caught a removed explicit null override field; JSON Patch restored it, and full spec equality passed at 08:33:57 UTC. The prior observation remains in CHECKS.md as RESTORED. This was a QA rollback representation difference, not a feature behavior failure.
