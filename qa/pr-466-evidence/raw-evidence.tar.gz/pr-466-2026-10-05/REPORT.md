# PR #466 — live quality assessment

**Recommendation: request changes before approval.** Live checks reproduced an operator metrics TLS policy update gap and an incompatible monitoring documentation example. The core operand TLS implementation passed the protocol, cipher, certificate, and functional checks.

PR/head: [openshift/cert-manager-operator#466](https://github.com/openshift/cert-manager-operator/pull/466), `b116f756e5333645814aeabfc0569933111bc5be`. Environment: OpenShift `5.0.0-0.nightly-2026-09-29-171841` on GCP, local operator, cert-manager `v1.20.3`, trust-manager `v0.20.3`.

The full procedures and reproduction commands are in [README.md](README.md). Per-assertion results and timestamps are in [CHECKS.md](CHECKS.md); the raw execution record is [commands.log](evidence/commands.log).

**Completed on 2026-10-05.** Recorded live assertions span 06:57–08:34 UTC: **441 PASS and 5 feature FAIL assertions**, plus one corrected test expectation, one interrupted rollback check, and one subsequently restored cleanup difference. All five feature failures are manifestations of F1. F2 was independently reproduced with real Prometheus targets. The four focused Go packages with tests also passed.

## Finding F1 — running operator metrics do not adopt changed cluster TLS policy

**Priority: high.** Tightening the cluster TLS policy leaves the already-running operator metrics listener accepting protocols/ciphers that the new policy excludes. The same binary started after the change enforces it correctly.

Observed examples:

| Cluster policy | Existing operator `:8443` | Fresh follower `:28443` | Five operand TLS listeners |
|---|---|---|---|
| Strict Modern | TLS 1.2 accepted | TLS 1.2 rejected | TLS 1.2 rejected |
| Strict Custom, minimum 1.2, AES128-GCM ECDHE only | Excluded `ECDHE-RSA-AES256-GCM-SHA384` accepted | Excluded cipher rejected | Excluded ciphers rejected |
| Strict Custom, minimum 1.3, empty cipher list | TLS 1.2 accepted | TLS 1.2 rejected | TLS 1.2 rejected |
| Strict Old, after local operator recovery | TLS 1.0/1.1 still rejected | TLS 1.0/1.1 accepted | TLS 1.0/1.1 accepted |

Positive controls negotiated TLS 1.3 successfully. In the first three rows, the original operator's certificate fingerprint stayed `64c415e6359cb4b777077f14128c303dd545c68a2758006fbec996298f2d08d5`, identifying the same listener. The Old retry used the restarted local operator; its fingerprint was `0b003c3e9391cd4dc91a3579f336e46971bcb9659099e331e2f07d90c8c64df8`. Both generations showed startup-only policy behavior.

Reproduction:

1. Start the local operator with default/Legacy adherence; verify TLS 1.2 works on `127.0.0.1:8443`.
2. Set APIServer `tlsAdherence=StrictAllComponents` and `tlsSecurityProfile={"type":"Modern","modern":{}}` using the README JSON patch.
3. Wait for operand rollouts; confirm their endpoints reject TLS 1.2.
4. Run `openssl s_client -connect 127.0.0.1:8443 -tls1_2 -brief </dev/null` against the original process. It still negotiates TLS 1.2.
5. Start a follower using the same binary, same kubeconfig, same leader namespace, and `--listen=127.0.0.1:28443`. It rejects TLS 1.2 and accepts TLS 1.3.

Evidence: [Modern handshakes](evidence/strict-modern-handshakes.json), [Custom 1.3 handshakes](evidence/strict-custom13-handshakes.json), and `strict-custom12` cipher assertions in [CHECKS.md](CHECKS.md).

Code explanation: [cmd.go](../../pkg/cmd/operator/cmd.go), line 138, calls `ApplyClusterProfileToHTTPServingInfo` once before constructing the server. The later `WithRestartOnChange` observes configuration/certificate files, not APIServer TLS changes. Trust-manager and cert-manager have separate APIServer-driven reconciliation, explaining the difference.

Recommendation: arrange operator listener reconfiguration or a managed restart when the honored APIServer TLS fields change, and add a live test that tightens both the minimum protocol and cipher list without manually restarting the process. If startup-only support is intentional, explicitly document the required restart and reconcile that limitation with the advertised TLS-profile support contract.

## Finding F2 — the documented ServiceMonitor still uses HTTP

**Priority: medium.** The PR enables HTTPS metrics unconditionally, including default/Legacy adherence. The example in [operand_metrics.md](../../docs/operand_metrics.md), lines 68–73, does not set `scheme: https` or configure certificate trust.

Observed on controller, webhook, and cainjector metrics:

```text
HTTP/1.0 400 Bad Request

Client sent an HTTP request to an HTTPS server.
```

The same endpoints returned HTTP 200 and Prometheus text over HTTPS with CA and service DNS verification. Setting the pod `prometheus.io/scheme=https` annotation does not change the explicitly configured ServiceMonitor endpoint protocol.

This was also reproduced with real OpenShift user-workload Prometheus: **3/3 HTTP targets DOWN with HTTP 400** at 08:02:05 UTC; **3/3 CA-verified HTTPS targets UP** with empty scrape errors at 08:03:13 UTC. Evidence: [HTTP targets](evidence/monitoring/monitoring-http-targets.json), [HTTPS targets](evidence/monitoring/monitoring-https-targets.json), and the [tested HTTPS monitor definitions](https-servicemonitors.json). The temporary monitoring configuration and ServiceMonitors were removed afterward.

Reproduction:

1. Forward any current Ready cert-manager operand pod's port 9402.
2. Request `http://127.0.0.1:<forwarded-port>/metrics`; observe HTTP 400.
3. Export only `cert-manager-metrics-ca`'s public `tls.crt`, request HTTPS with that CA and the corresponding service DNS identity, and observe HTTP 200.
4. Use the real Prometheus reproduction described in the README to compare HTTP targets with CA-verified HTTPS targets.

Recommendation: update the monitoring example and upgrade/migration guidance. Configure HTTPS, trust the metrics CA, and set the correct server identity for each component. Existing HTTP ServiceMonitors need an explicit migration; the annotation alone does not migrate them.

## Scenario results

All eight baseline/profile stages and the additional live scenarios below were executed. The five failed TLS assertions all map to F1; F2 is recorded as a successful reproduction of the expected HTTP scrape failure. Retried-stage assertions remain in the evidence, so assertion totals are not counts of distinct scenarios.

| Scenario | Expected behavior | Outcome |
|---|---|---|
| Baseline: both APIServer TLS fields absent | Component defaults; HTTPS metrics already active | PASS |
| Strict with absent profile | Intermediate defaults, minimum TLS 1.2 | PASS |
| Strict Intermediate | Accept TLS 1.2/1.3; reject 1.0/1.1 | PASS |
| Intermediate → Modern | All operands move to TLS 1.3; cipher flags disappear | PASS for operands/fresh operator; F1 on original operator |
| Modern → Custom TLS 1.2 | Correct minimum and allowed/excluded cipher behavior | PASS for operands/fresh operator; F1 on original operator |
| Custom TLS 1.2 → Custom TLS 1.3 | Minimum 1.3; no operand cipher flags despite empty profile list | PASS for operands/fresh operator; F1 on original operator |
| Old profile | Correct flags and actual TLS 1.0–1.3 negotiation | PASS for operands/fresh operator; F1 on existing operator |
| Strict → Legacy with Modern profile retained | Remove cluster-derived flags; retain HTTPS metrics | PASS; actual listeners return to minimum TLS 1.2 |
| Metrics CA/SAN verification | Valid trusted serving certs on all three metrics endpoints | PASS in every completed profile |
| Cert-manager/trust-manager webhook certificates | Correct CA chains and service DNS identities | PASS in every completed profile |
| Certificate issuance and reissuance | Current-generation Ready Certificate after each profile | PASS in every completed profile |
| Existing Bundle through profile changes | Synced Bundle and populated target ConfigMap | PASS across the profile matrix |
| Fresh Bundle reconciliation after restoration | Changed spec admitted; current generation Synced; exact source CA delivered | PASS: generation 2 and matching DER SHA-256 fingerprints |
| Trust-manager serving Certificate | Remains Ready through profile changes | PASS |
| Trust-manager metrics control | Existing plaintext HTTP behavior retained | PASS; intentionally outside the PR's webhook TLS scope |
| Malformed profiles and adherence | Server-side dry-run rejected, no stored invalid configuration | PASS: six negative cases |
| Metrics RBAC | Updates restricted to named CA in the new Role; three subjects | PASS |
| RBAC drift/deletion | Deleted metrics Role/RoleBinding recreated | PASS |
| Unrelated APIServer update | No operand Deployment generation changes | PASS |
| Direct trust-manager TLS argument drift | SSA restores configured minimum | PASS: tampered 1.3 restored to cluster-default 1.2 |
| Operand restarts | New pods retain TLS behavior and functional certificate issuance | PASS on all four operands |
| Metrics CA persistence | Pod restarts preserve shared CA | PASS: original and current public CA match |
| Unsupported controller override | Override affects controller metrics; other operands keep cluster policy | PASS: controller enforces 1.3 while trust-manager accepts 1.2; override restored |
| Operator serving integration | Service annotation, Secret, mount, valid DNS cert | PASS for manifest/live-resource checks |
| Actual OpenShift service certificate served locally | Validate CA chain and correct Service DNS; reject wrong DNS | PASS; explicit temporary serving configuration |
| Operator metrics authorization over HTTPS | Anonymous denied; authorized metrics-reader allowed | PASS: 403 anonymous, 200 with Prometheus text when authorized |
| Real Prometheus HTTP-to-HTTPS migration | HTTP fails; trusted HTTPS scrapes succeed | F2 reproduced; corrected HTTPS configuration PASS on all three targets |
| Source and bundle CSV feature claims | `tls-profiles: "true"` in both | PASS |
| Focused unit suites | Tests pass in TLS/common/trust-manager/cert-manager packages | PASS; operator command package has no test files |

## Coverage boundaries

The test installation uses a local macOS operator and upstream operand images. Do not treat these results as production-image/FIPS certification, a packaged OLM installation or upgrade test, or an exhaustive supported-platform matrix.

The following need separate environments or longer-duration tests:

- OLM installation/upgrade and actual operator container mount behavior; only source/bundle manifests and the live scaled-down Deployment were available here.
- Production Red Hat/FIPS images and architectures other than this local arm64 binary and the supplied GCP cluster.
- Natural CA/leaf expiry rotation and operator projected-volume rotation/restart; pod restarts and active certificate validation are separate, shorter lifecycle checks.
- TrustManager feature gate disabled, absent OpenShift APIs, denied APIServer reads, and unavailable API startup behavior in a live installation. Missing/forbidden APIServer helper paths were exercised by unit tests; a real startup during API unavailability was not tested.
- Custom TLS supported groups/curves exposed by this newer cluster API; the PR's vendored API/helpers implement minimum-version and cipher handling. No supported-group claim is established by this run.
- Sustained load, prolonged outage/reconnect, and long-running soak behavior.

## Cleanup and execution qualifications

The original APIServer profile was absent. Once `tlsAdherence` was set, the cluster's CEL validation rejected removing it. Cleanup left `LegacyAdheringComponentsOnly` explicitly set, with the profile absent: original effective behavior, but an intentional spec delta. No API validation bypass or APIServer deletion was used.

An initial RBAC assertion incorrectly expected the main cert-manager controller to lack update access to unrelated Secrets. Inspection showed that its pre-existing certificate-management ClusterRole already grants this access. That observation is marked CORRECTED in CHECKS.md, not counted as a PR defect.

An early rollback convergence assertion failed while the original local operator was no longer running during platform/API disruption. It is retained as an execution incident, separate from F1/F2. The local operator was restarted from the existing binary with the original Makefile image settings, explicit KUBECONFIG, and TrustManager enabled. Its PID is `63021`; [launch details](evidence/restarted-local-operator.json) and [logs](evidence/restarted-local-operator.log) are preserved. Its original exit cause could not be proven because the original stdout was unavailable.

The recovery/drift stage used Strict default/Intermediate. Historical profile-stage Bundle checks established continued Synced status and target presence; the final functional stage separately forced a new generation and verified exact CA contents. These qualifications are reflected in CHECKS.md instead of silently upgrading the older measurements.

Final verification completed at **08:31:25 UTC**: all four operand Deployments were ready, TrustManager was Ready, the restarted local operator held its leader lease, and all temporary followers/port-forwards were stopped. The test Bundle, namespace, source ConfigMap, temporary cluster RBAC and ServiceMonitors were absent. The monitoring ConfigMap data matched its original value, and temporary user-workload monitoring pods were gone. The background platform check had also completed: all 35 ClusterOperators healthy, all six nodes Ready/schedulable, and both machine pools Updated/nondegraded. See [final snapshot](evidence/final.json) and [platform snapshot](evidence/final-platform.json).

One exact-spec cleanup comparison found `unsupportedConfigOverrides` absent instead of its original explicit `null`; effective behavior was unchanged. JSON Patch restored the original field at the end of the run, and the complete CertManager spec matched its baseline. This is marked RESTORED, not a feature defect; the authoritative later object is [final-certmanager-exact-restore.json](evidence/final-certmanager-exact-restore.json). The saved override test driver now preserves null field presence on rollback.

No production implementation files were changed by this QA run. The user's original tracked changes match the captured baseline patch. All reports and evidence are local files and survive destruction of the test cluster.
