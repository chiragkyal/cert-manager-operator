#!/usr/bin/env python3
"""Additional PR 466 QA: admission, drift, restarts, overrides and metrics auth."""
import base64
import http.client
import json
from pathlib import Path
import ssl
import sys
import tempfile
import time
import live_check as q
MINIMUM='1.3'

def wait(check, timeout=100):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:
            if check():
                return True
        except Exception:
            pass
        time.sleep(3)
    return False

def admission():
    q.PHASE='admission'
    cases=[('unknown-profile', 'StrictAllComponents', {'type':'Nonexistent'}),
           ('missing-custom', 'StrictAllComponents', {'type':'Custom'}),
           ('invalid-minimum', 'StrictAllComponents', {'type':'Custom','custom':{'minTLSVersion':'TLS9','ciphers':['ECDHE-RSA-AES128-GCM-SHA256']}}),
           ('empty-cipher-list', 'StrictAllComponents', {'type':'Custom','custom':{'minTLSVersion':'VersionTLS12','ciphers':[]}}),
           ('unknown-adherence', 'Nonexistent', {'type':'Intermediate','intermediate':{}}),
           ('configurable-tls13-ciphers','StrictAllComponents',{'type':'Custom','custom':{'minTLSVersion':'VersionTLS13','ciphers':['TLS_AES_128_GCM_SHA256']}})]
    for name, adherence, profile in cases:
        p=q.patch_tls(adherence, profile, dry=True)
        q.result('API rejects '+name,p.returncode!=0,p.stdout+p.stderr,'server-side dry run rejected; no mutation')

def rbac_and_packaging():
    q.PHASE='rbac-packaging'
    role=q.get('role','cert-manager-metrics-dynamic-serving','-n','cert-manager')
    binding=q.get('rolebinding','cert-manager-metrics-dynamic-serving','-n','cert-manager')
    rules=role['rules']
    ok=all(r.get('resourceNames')==['cert-manager-metrics-ca'] for r in rules if 'update' in r['verbs'])
    q.result('new Role scopes updates to metrics CA',ok,rules)
    q.result('RoleBinding covers all three service accounts',set(s['name'] for s in binding['subjects'])==set(q.NAMES[:3]),binding['subjects'])
    # The controller already manages arbitrary Certificate output Secrets. Its
    # aggregate permission is intentionally broader than this new Role.
    controller=q.get('clusterrole','cert-manager-controller-certificates')
    q.result('baseline controller broad Secret access is pre-existing',any('secrets' in r.get('resources',[]) and 'update' in r['verbs'] for r in controller['rules']),controller['rules'])
    for kind, old in [('role',role),('rolebinding',binding)]:
        q.oc('delete',kind,old['metadata']['name'],'-n','cert-manager')
        recreated=wait(lambda:q.get(kind,old['metadata']['name'],'-n','cert-manager')['metadata']['uid']!=old['metadata']['uid'])
        q.result(kind+' recreated after deletion',recreated,'operator static-resource reconciliation')
        if not recreated:
            # Explicitly restore if the test finds a reconciliation defect.
            clean={k:v for k,v in old.items() if k in ['apiVersion','kind','rules','subjects','roleRef']}
            clean['metadata']={'name':old['metadata']['name'],'namespace':'cert-manager','labels':old['metadata'].get('labels',{})}
            q.apply(clean)
    svc=q.get('service','cert-manager-operator-controller-manager-metrics-service','-n','cert-manager-operator')
    dep=q.get('deploy','cert-manager-operator-controller-manager','-n','cert-manager-operator')
    secret='cert-manager-operator-serving-cert'
    q.result('operator metrics Service requests serving certificate',svc['metadata'].get('annotations',{}).get('service.beta.openshift.io/serving-cert-secret-name')==secret,svc['metadata'].get('annotations',{}))
    volumes=dep['spec']['template']['spec']['volumes']
    mounts=dep['spec']['template']['spec']['containers'][0]['volumeMounts']
    q.result('operator Deployment mounts optional serving Secret',any(v.get('secret',{}).get('secretName')==secret and v['secret'].get('optional') for v in volumes) and any(m['mountPath']=='/var/run/secrets/serving-cert' and m.get('readOnly') for m in mounts),{'volumes':volumes,'mounts':mounts,'replicas':dep['spec']['replicas']})
    cert=q.public_cert(secret,namespace='cert-manager-operator')
    out=q.run(['openssl','x509','-noout','-subject','-issuer','-dates','-ext','subjectAltName'],data=cert)
    q.result('service-ca issued operator DNS certificate', 'cert-manager-operator-controller-manager-metrics-service.cert-manager-operator.svc' in out.stdout,out.stdout)
    for name in ['bundle/manifests/cert-manager-operator.clusterserviceversion.yaml','config/manifests/bases/cert-manager-operator.clusterserviceversion.yaml']:
        lines=[s.strip() for s in (q.ROOT/name).read_text().splitlines() if 'features.operators.openshift.io/tls-profiles:' in s]
        q.result('CSV TLS feature claim '+name, bool(lines) and '"true"' in lines[0],lines)

def stability_and_drift():
    q.PHASE='stability-drift'
    before=q.get('deploy','-n','cert-manager')
    generations={d['metadata']['name']:d['metadata']['generation'] for d in before['items']}
    q.oc('annotate','apiserver','cluster','qa.cert-manager-operator/pr466=predicate-check','--overwrite')
    time.sleep(20)
    after=q.get('deploy','-n','cert-manager')
    q.result('unrelated APIServer annotation causes no rollouts',generations=={d['metadata']['name']:d['metadata']['generation'] for d in after['items']},generations)
    q.oc('annotate','apiserver','cluster','qa.cert-manager-operator/pr466-')
    tm=q.get('deploy','trust-manager','-n','cert-manager')
    args=tm['spec']['template']['spec']['containers'][0]['args']
    altered='13' if MINIMUM=='1.2' else '12'
    changed=[a.replace('--tls-min-version=VersionTLS'+MINIMUM.replace('.',''),'--tls-min-version=VersionTLS'+altered) for a in args]
    q.oc('patch','deploy','trust-manager','-n','cert-manager','--type=json','-p',json.dumps([{'op':'replace','path':'/spec/template/spec/containers/0/args','value':changed}]))
    q.result('SSA repairs altered trust-manager TLS minimum',q.converge(MINIMUM),'expected TLS'+MINIMUM+' restored after direct Deployment mutation')
    oldpods=q.get('pods','-n','cert-manager')
    old_uids={p['metadata']['uid'] for p in oldpods['items']}
    # Restart existing operand pods; do not add persistent restart annotations.
    for pod in oldpods['items']:
        if pod['status'].get('phase')=='Running':
            q.oc('delete','pod',pod['metadata']['name'],'-n','cert-manager','--wait=false')
    newpods=wait(lambda:all(p['metadata']['uid'] not in old_uids for p in q.get('pods','-n','cert-manager')['items']),120)
    healthy=q.converge(MINIMUM)
    q.result('operand pod restart retains TLS configuration',newpods and healthy,'all old pod UIDs replaced; rollout converged')
    original_ca=q.get('configmap','cmo-pr466-source','-n','cert-manager')['data']['ca.crt']
    current_ca=q.public_cert('cert-manager-metrics-ca')
    q.result('shared metrics CA survives operand restarts',original_ca==current_ca,'current public CA equals the baseline source ConfigMap certificate')
    q.forwards()
    try:
        for name,port in list(q.ENDPOINTS.items())[:5]:
            lower_version={'1.0':'1.0','1.2':'1.1','1.3':'1.2'}[MINIMUM]
            lower=q.probe(port,lower_version); accepted=q.probe(port,'1.3')
            minimum=q.probe(port,MINIMUM) if MINIMUM!='1.3' else accepted
            q.result(name+' TLS after pod restart',lower['accepted']==(MINIMUM=='1.0') and minimum['accepted'] and accepted['accepted'],{'lower TLS'+lower_version:lower,'minimum TLS'+MINIMUM:minimum,'TLS1.3':accepted})
        q.functional()
    finally:
        q.stop_all()

def overrides():
    q.PHASE='override-precedence'
    original_spec=json.loads((q.OUT/'original-certmanager.json').read_text())['spec']
    original=original_spec.get('unsupportedConfigOverrides')
    try:
        override_minimum='1.3' if MINIMUM=='1.2' else '1.2'
        override_args=['--metrics-tls-min-version=VersionTLS'+override_minimum.replace('.','')]
        if override_minimum=='1.2':
            override_args.append('--metrics-tls-cipher-suites=TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256')
        override={'controller':{'args':override_args}}
        q.oc('patch','certmanager','cluster','--type=merge','-p',json.dumps({'spec':{'unsupportedConfigOverrides':override}}))
        def ready():
            dep=q.get('deploy','cert-manager','-n','cert-manager')
            args=dep['spec']['template']['spec']['containers'][0]['args']
            s=dep.get('status',{})
            return override_args[0] in args and s.get('observedGeneration')==dep['metadata']['generation'] and s.get('replicas')==s.get('readyReplicas')==s.get('updatedReplicas')==1
        settled=wait(ready,180)
        q.result('unsupported controller override takes precedence',settled,q.get('deploy','cert-manager','-n','cert-manager')['spec']['template']['spec']['containers'][0]['args'])
        q.forwards()
        accepted=q.probe(19402,override_minimum)
        if MINIMUM=='1.2':
            denied=q.probe(19402,'1.2')
            untouched=q.probe(19444,'1.2')
            q.result('override affects actual metrics listener only',accepted['accepted'] and not denied['accepted'] and untouched['accepted'],{'controller TLS1.3':accepted,'controller TLS1.2':denied,'trust-manager TLS1.2':untouched})
        elif MINIMUM=='1.0':
            denied=q.probe(19402,'1.0')
            untouched=q.probe(19444,'1.0')
            q.result('override affects actual metrics listener only',accepted['accepted'] and not denied['accepted'] and untouched['accepted'],{'controller TLS1.2':accepted,'controller TLS1.0':denied,'trust-manager TLS1.0':untouched})
        else:
            untouched=q.probe(19444,'1.2')
            q.result('override affects actual metrics listener only',accepted['accepted'] and not untouched['accepted'],{'controller':accepted,'trust-manager':untouched})
    finally:
        q.stop_all()
        # JSON Merge Patch deletes null fields; preserve original field presence.
        operation={'op':'add','path':'/spec/unsupportedConfigOverrides','value':original} if 'unsupportedConfigOverrides' in original_spec else {'op':'remove','path':'/spec/unsupportedConfigOverrides'}
        q.oc('patch','certmanager','cluster','--type=json','-p',json.dumps([operation]))
        q.converge(MINIMUM)

def metrics_auth():
    q.PHASE='operator-metrics-auth'
    name=q.NS+'-metrics'
    q.apply({'apiVersion':'v1','kind':'ServiceAccount','metadata':{'name':'metrics-reader','namespace':q.NS}})
    q.apply({'apiVersion':'rbac.authorization.k8s.io/v1','kind':'ClusterRole','metadata':{'name':name},'rules':[{'nonResourceURLs':['/metrics'],'verbs':['get']}]})
    q.apply({'apiVersion':'rbac.authorization.k8s.io/v1','kind':'ClusterRoleBinding','metadata':{'name':name},'roleRef':{'apiGroup':'rbac.authorization.k8s.io','kind':'ClusterRole','name':name},'subjects':[{'kind':'ServiceAccount','name':'metrics-reader','namespace':q.NS}]})
    try:
        q.follower()
        token=q.oc('create','token','metrics-reader','-n',q.NS,'--duration=10m',record=False).stdout.strip()
        def request(token=None):
            context=ssl._create_unverified_context()
            context.minimum_version=ssl.TLSVersion.TLSv1_3
            conn=http.client.HTTPSConnection('127.0.0.1',q.FOLLOWER_PORT,context=context,timeout=15)
            conn.request('GET','/metrics',headers={'Authorization':'Bearer '+token} if token else {})
            response=conn.getresponse();body=response.read().decode(errors='replace');conn.close()
            return {'status':response.status,'prometheus':'# HELP' in body and '# TYPE' in body,'bytes':len(body)}
        anon=request()
        authenticated=request(token)
        q.result('operator metrics denies anonymous request',anon['status'] in [401,403],anon)
        q.result('operator metrics permits authorized HTTPS scrape',authenticated['status']==200 and authenticated['prometheus'],authenticated)
    finally:
        q.stop_all()
        q.oc('delete','clusterrolebinding',name,'--ignore-not-found')
        q.oc('delete','clusterrole',name,'--ignore-not-found')

def serving_certificate():
    q.PHASE='operator-service-ca'
    q.apply({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'service-ca','namespace':q.NS,'annotations':{'service.beta.openshift.io/inject-cabundle':'true'}}})
    injected=wait(lambda:'service-ca.crt' in q.get('configmap','service-ca','-n',q.NS).get('data',{}))
    q.result('OpenShift service CA bundle injected',injected,'test namespace ConfigMap')
    if not injected:
        return
    ca=q.get('configmap','service-ca','-n',q.NS)['data']['service-ca.crt']
    # Use a private temporary directory, and never log Secret data/key material.
    # This checks the actual issued certificate through the local serving code.
    # The default mount-path selection in a deployed image remains untested.
    with tempfile.TemporaryDirectory(prefix='pr466-serving-') as td:
        path=Path(td)
        cert=q.public_cert('cert-manager-operator-serving-cert',namespace='cert-manager-operator')
        raw=q.oc('get','secret','cert-manager-operator-serving-cert','-n','cert-manager-operator','-o','jsonpath={.data.tls\\.key}',record=False).stdout
        (path/'tls.crt').write_text(cert)
        (path/'tls.key').write_bytes(base64.b64decode(raw))
        (path/'tls.key').chmod(0o600)
        config={'apiVersion':'operator.openshift.io/v1alpha1','kind':'GenericOperatorConfig','servingInfo':{'bindNetwork':'tcp','certFile':str(path/'tls.crt'),'keyFile':str(path/'tls.key')}}
        (path/'config.json').write_text(json.dumps(config))
        try:
            q.follower(path/'config.json')
            dns='cert-manager-operator-controller-manager-metrics-service.cert-manager-operator.svc'
            obs=q.probe(q.FOLLOWER_PORT,'1.3',ca=ca,hostname=dns)
            q.result('operator serves real service-ca certificate',obs['accepted'],obs,'TLS1.3; chain and Service DNS verified')
            mismatch=q.probe(q.FOLLOWER_PORT,'1.3',ca=ca,hostname='wrong.example.test')
            q.result('operator certificate rejects wrong DNS identity',not mismatch['accepted'] and 'CERTIFICATE_VERIFY_FAILED' in mismatch.get('error',''),mismatch)
        finally:
            q.stop_all()

def main():
    global MINIMUM
    mode=sys.argv[1] if len(sys.argv)>1 else 'all'
    if mode=='default':
        MINIMUM='1.2'
    if mode=='current-old':
        q.PHASE='extended-current-old'
        if not q.wait_platform():
            raise RuntimeError('API/platform availability did not recover')
        config=q.get('apiserver','cluster')['spec']
        if config.get('tlsAdherence')!='StrictAllComponents' or config.get('tlsSecurityProfile',{}).get('type')!='Old':
            raise RuntimeError('This mode requires the already-applied Strict Old profile')
        MINIMUM='1.0'
        try:
            stability_and_drift()
            overrides()
        finally:
            q.stop_all()
        return
    if mode=='serving':
        # These checks do not mutate the profile and accept TLS1.3 under every
        # tested policy. Separate listener/evidence avoid concurrent stage clashes.
        q.FOLLOWER_PORT=38443
        q.OUT=q.OUT/'serving'
        q.OUT.mkdir(exist_ok=True)
        metrics_auth()
        serving_certificate()
        return
    if mode in ['all','preflight']:
        admission()
        rbac_and_packaging()
    if mode=='preflight':
        return
    try:
        q.PHASE='extended-default' if MINIMUM=='1.2' else 'extended-modern'
        if not q.wait_platform():
            raise RuntimeError('Platform must settle before extended TLS testing')
        q.patch_tls('StrictAllComponents',None if MINIMUM=='1.2' else {'type':'Modern','modern':{}})
        if not q.converge(MINIMUM):
            return
        stability_and_drift()
        overrides()
        if mode not in ['modern-only','default']:
            metrics_auth()
            serving_certificate()
    finally:
        q.PHASE='extended-restore'
        q.stop_all()
        q.restore()
        q.converge(None)

if __name__=='__main__':
    main()
