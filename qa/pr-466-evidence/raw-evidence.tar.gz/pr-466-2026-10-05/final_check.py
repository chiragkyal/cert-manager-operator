#!/usr/bin/env python3
"""Read-only final recovery, restoration, and cleanup verification."""
import datetime
import json
import os
import socket
import sys
import time
import live_check as q

q.PHASE = 'final-validation'

def conditions(obj):
    return {c['type']:c['status'] for c in obj.get('status',{}).get('conditions',[])}

def health():
    data = {name:q.get(resource) for name,resource in [('nodes','nodes'),('pools','mcp'),('operators','clusteroperators')]}
    pending=[]
    for node in data['nodes']['items']:
        if conditions(node).get('Ready')!='True' or node['spec'].get('unschedulable',False):
            pending.append('node/'+node['metadata']['name'])
    for pool in data['pools']['items']:
        c=conditions(pool)
        if c.get('Updated')!='True' or c.get('Updating')!='False' or c.get('Degraded')!='False':
            pending.append('pool/'+pool['metadata']['name'])
    for operator in data['operators']['items']:
        c=conditions(operator)
        if c.get('Available')!='True' or c.get('Progressing')!='False' or c.get('Degraded')!='False':
            pending.append('operator/'+operator['metadata']['name'])
    return data,pending

skip_wait='--no-wait' in sys.argv
end=time.monotonic()+900
data={};pending=['not yet sampled'];samples=0
while time.monotonic()<end:
    try:
        data,pending=health()
        samples=samples+1 if not pending else 0
        print('Final recovery: '+(', '.join(pending) or 'healthy'),flush=True)
        if samples>=2 or skip_wait:
            break
    except Exception as exc:
        samples=0
        print('Waiting for API: '+str(exc)[:160],flush=True)
    time.sleep(20)
q.save('final-platform',data)
if skip_wait:
    q.save('final-recovery-qualification',{'time':q.stamp(),'pending':pending,'qualification':'User explicitly prioritized feature testing over cluster recovery; further recovery waiting was stopped. This is a platform-state observation, not a feature-test failure.'})
else:
    q.result('all nodes, machine pools and platform operators recovered',samples>=2,{'pending':pending,'healthy_samples':samples},'two samples: nodes Ready/schedulable, pools Updated/nondegraded, operators Available/nonprogressing/nondegraded')

state=q.snapshot('final')
original=json.loads((q.OUT/'original-apiserver.json').read_text())
expected=dict(original['spec'])
expected['tlsAdherence']='LegacyAdheringComponentsOnly'
q.result('APIServer effective baseline restored',state['apiserver']['spec']==expected,state['apiserver']['spec'],'original spec plus explicit Legacy adherence required by CEL')
q.result('QA APIServer annotation removed','qa.cert-manager-operator/pr466' not in state['apiserver']['metadata'].get('annotations',{}),'annotation absent')
original_cm=json.loads((q.OUT/'original-certmanager.json').read_text())
cm=q.get('certmanager','cluster')
q.result('CertManager original spec restored',cm['spec']==original_cm['spec'],cm['spec'])
baseline=json.loads((q.OUT/'baseline.json').read_text())
tm=q.get('trustmanager','cluster')
original_tm=next(item for item in baseline['operators']['items'] if item['kind']=='TrustManager')
q.result('TrustManager spec preserved and Ready',tm['spec']==original_tm['spec'] and conditions(tm).get('Ready')=='True',{'spec':tm['spec'],'conditions':conditions(tm)})
q.result('all four operand Deployments ready',all(d['status'].get('readyReplicas')==1 and d['status'].get('updatedReplicas')==1 and d['status'].get('replicas')==1 for d in state['deployments']['items']) and {d['metadata']['name'] for d in state['deployments']['items']}==set(q.NAMES),{d['metadata']['name']:d['status'] for d in state['deployments']['items']})

for kind,name,namespace in [('bundle',q.NS,None),('namespace',q.NS,None),('configmap','cmo-pr466-source','cert-manager'),('clusterrole','cmo-pr466-qa-metrics',None),('clusterrolebinding','cmo-pr466-qa-metrics',None)]:
    args=['get',kind,name,'--ignore-not-found','-o','name']
    if namespace:
        args+=['-n',namespace]
    p=q.oc(*args)
    q.result('QA '+kind+'/'+name+' removed',not p.stdout.strip(),p.stdout.strip() or 'absent')
monitors=q.get('servicemonitor','-n','cert-manager')
remaining=[m['metadata']['name'] for m in monitors['items'] if m['metadata']['name'].startswith('cmo-pr466-')]
q.result('QA ServiceMonitors removed',not remaining,remaining)
monitoring=q.get('configmap','cluster-monitoring-config','-n','openshift-monitoring')
original_monitoring=json.loads((q.OUT/'monitoring/original-cluster-monitoring-config.json').read_text())
q.result('monitoring ConfigMap data restored exactly',monitoring.get('data')==original_monitoring.get('data'),'data equals original' if monitoring.get('data')==original_monitoring.get('data') else 'data differs')
uwm=q.get('pods','-n','openshift-user-workload-monitoring')
q.result('temporary user-workload monitoring pods removed',not uwm['items'],[p['metadata']['name'] for p in uwm['items']])

leader=q.get('lease','cert-manager-operator-lock','-n','cert-manager-operator')
renew=datetime.datetime.fromisoformat(leader['spec']['renewTime'].replace('Z','+00:00'))
age=(datetime.datetime.now(datetime.timezone.utc)-renew).total_seconds()
pid=json.loads((q.OUT/'restarted-local-operator.json').read_text())['pid']
try:
    os.kill(pid,0)
    running=True
except OSError:
    running=False
q.result('restarted local operator remains active leader',running and age<60,{'pid':pid,'running':running,'holderIdentity':leader['spec']['holderIdentity'],'lease_age_seconds':age})
for version in ['1.2','1.3']:
    probe=q.probe(8443,version)
    q.result('final operator metrics accepts TLS'+version,probe['accepted'],probe)
ports=[19402,19403,19404,19443,19444,19405,28443,38443,19090,19091]
open_ports=[]
for port in ports:
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.5):
            open_ports.append(port)
    except OSError:
        pass
q.result('QA followers and port-forwards stopped',not open_ports,{'still_listening':open_ports})
q.save('final-verification-time',{'time':q.stamp(),'operator_pid':pid})
