#!/usr/bin/env python3
"""PR 466 live QA. Run from repository root; evidence excludes credentials.

Uses an existing local leader, disposable follower listeners, and pod forwards.
Profile runs restore APIServer TLS fields in finally. Cleanup removes only QA
resources. Test commands and their output are recorded in evidence/commands.log.
"""
import base64
import concurrent.futures
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import socket
import ssl
import subprocess
import sys
import time
import warnings

warnings.filterwarnings('ignore', category=DeprecationWarning)
ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent / 'evidence'
KUBE = ROOT / 'cluster-bot-2026-10-05-051927.kubeconfig'
OC = ['oc', '--kubeconfig=' + str(KUBE), '--request-timeout=30s']
NS = 'cmo-pr466-qa'
NAMES = ['cert-manager', 'cert-manager-cainjector', 'cert-manager-webhook', 'trust-manager']
PROCS = []
PHASE = 'setup'
FOLLOWER_PORT = 28443

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, obj):
    (OUT / (name + '.json')).write_text(json.dumps(obj, indent=2) + '\n')

def run(args, data=None, check=True, record=True, timeout=90):
    p = subprocess.run(args, input=data, capture_output=True, text=True, timeout=timeout, cwd=ROOT)
    if record:
        with (OUT / 'commands.log').open('a') as f:
            f.write(f'\n[{stamp()}] {PHASE}\n$ {shlex.join(args)}\n')
            if data:
                f.write('STDIN:\n' + data + '\n')
            f.write(p.stdout + p.stderr + f'\nEXIT: {p.returncode}\n')
    if check and p.returncode:
        raise RuntimeError(f'{shlex.join(args[:8])}: {p.stderr.strip()}')
    return p

def oc(*args, **kw):
    return run(OC + list(args), **kw)

def get(*args):
    for attempt in range(3):
        try:
            return json.loads(oc('get', *args, '-o', 'json').stdout)
        except RuntimeError as e:
            if attempt == 2 or not any(s in str(e).lower() for s in ['timeout','timed out','connection','eof','unavailable']):
                raise
            time.sleep(2)

def result(name, ok, details, expected=''):
    item = dict(time=stamp(), phase=PHASE, test=name, result='PASS' if ok else 'FAIL', expected=expected, observed=details)
    with (OUT / 'results.jsonl').open('a') as f:
        f.write(json.dumps(item) + '\n')
    print(f"{item['result']} {PHASE}: {name}: {str(details)[:240]}", flush=True)

def apply(obj):
    return oc('apply', '-f', '-', data=json.dumps(obj))

def snapshot(label):
    data = {}
    for name, args in {
        'apiserver': ['apiserver', 'cluster'],
        'deployments': ['deploy', '-n', 'cert-manager'],
        'pods': ['pods', '-n', 'cert-manager'],
        'operators': ['certmanager,trustmanager'],
        'clusteroperators': ['clusteroperators'],
        'operator-deployment': ['deploy', '-n', 'cert-manager-operator'],
    }.items():
        data[name] = get(*args)
    save(label, data)
    return data

def public_cert(secret, key='tls.crt', namespace='cert-manager'):
    # Fetch only the public cert field. Never request or record private keys.
    raw = oc('get', 'secret', secret, '-n', namespace, '-o', 'jsonpath={.data.' + key.replace('.', '\\.') + '}').stdout
    return base64.b64decode(raw).decode()

def stop(p):
    if p.poll() is None:
        p.terminate()
        try:
            p.wait(timeout=10)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait(timeout=5)

def stop_all():
    for p in reversed(PROCS):
        stop(p)
    PROCS.clear()

def background(args, name):
    with (OUT / 'commands.log').open('a') as f:
        f.write(f'\n[{stamp()}] {PHASE}\n$ {shlex.join(args)} [background]\n')
    log = (OUT / f'{PHASE}-{name}.log').open('w')
    env = os.environ.copy()
    env['KUBECONFIG'] = str(KUBE)
    p = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT, env=env)
    log.close()
    PROCS.append(p)
    return p

def wait_port(port, p, timeout=45):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if p.poll() is not None:
            raise RuntimeError(f'listener process exited {p.returncode}, port={port}')
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=1):
                return
        except OSError:
            time.sleep(0.5)
    raise RuntimeError(f'port {port} not ready')

def forwards():
    plans = [('cert-manager', ['19402:9402']), ('cert-manager-cainjector', ['19403:9402']),
             ('cert-manager-webhook', ['19404:9402', '19443:10250']),
             ('trust-manager', ['19444:6443', '19405:9402'])]
    for dep, ports in plans:
        # Deployment port-forward can select a Pending or terminating pod during
        # a rollout. Pin probes to a Ready pod with the desired container args.
        pod_name = None
        end = time.monotonic() + 150
        while time.monotonic() < end and not pod_name:
            desired = get('deploy', dep, '-n', 'cert-manager')
            selector = desired['spec']['selector']['matchLabels']
            pods = get('pods', '-n', 'cert-manager', '-l', ','.join(k+'='+v for k,v in selector.items()))
            for pod in pods['items']:
                if pod['metadata'].get('deletionTimestamp') or pod['status'].get('phase') != 'Running':
                    continue
                if not all(s.get('ready') for s in pod['status'].get('containerStatuses', [])):
                    continue
                if pod['spec']['containers'][0]['args'] != desired['spec']['template']['spec']['containers'][0]['args']:
                    continue
                pod_name = pod['metadata']['name']
                break
            if not pod_name:
                time.sleep(3)
        if not pod_name:
            raise RuntimeError('No Ready current pod for ' + dep)
        for attempt in range(3):
            p = background(OC + ['port-forward', '-n', 'cert-manager', 'pod/' + pod_name] + ports, 'forward-' + dep + '-' + str(attempt))
            try:
                for port in ports:
                    wait_port(int(port.split(':')[0]), p, timeout=60)
                break
            except RuntimeError:
                stop(p)
                if attempt == 2:
                    raise
                time.sleep(3)

def follower(config='./hack/local-run-config.yaml'):
    lease = get('lease', 'cert-manager-operator-lock', '-n', 'cert-manager-operator')
    before = lease['spec']['holderIdentity']
    if not before:
        raise RuntimeError('No existing operator leader; restore the local operator before starting a test follower')
    p = background([str(ROOT / 'cert-manager-operator'), 'start', '--config=' + str(config),
                    '--kubeconfig=' + str(KUBE), '--namespace=cert-manager-operator',
                    '--listen=127.0.0.1:' + str(FOLLOWER_PORT), '--v=2'], 'operator-follower')
    wait_port(FOLLOWER_PORT, p)
    after = get('lease', 'cert-manager-operator-lock', '-n', 'cert-manager-operator')['spec']['holderIdentity']
    result('follower preserves existing leader', before == after, {'before': before, 'after': after})
    return p

VERSIONS = {'1.0': ssl.TLSVersion.TLSv1, '1.1': ssl.TLSVersion.TLSv1_1,
            '1.2': ssl.TLSVersion.TLSv1_2, '1.3': ssl.TLSVersion.TLSv1_3}

def probe(port, version='1.3', cipher=None, ca=None, hostname='localhost', http=None):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = bool(ca)
    ctx.verify_mode = ssl.CERT_REQUIRED if ca else ssl.CERT_NONE
    if ca:
        ctx.load_verify_locations(cadata=ca)
    ctx.minimum_version = ctx.maximum_version = VERSIONS[version]
    ctx.set_ciphers((cipher or 'ALL') + ':@SECLEVEL=0')
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=8) as raw:
            with ctx.wrap_socket(raw, server_hostname=hostname) as sock:
                cert = sock.getpeercert(binary_form=True)
                info = dict(accepted=True, protocol=sock.version(), cipher=sock.cipher()[0],
                            certificate_sha256=hashlib.sha256(cert).hexdigest())
                if ca:
                    info['certificate'] = sock.getpeercert()
                if http:
                    sock.sendall(f'GET {http} HTTP/1.1\r\nHost: {hostname}\r\nConnection: close\r\n\r\n'.encode())
                    output = b''
                    while len(output) < 2097152:
                        data = sock.recv(32768)
                        if not data:
                            break
                        output += data
                    text = output.decode(errors='replace')
                    info.update(status=text.split('\r\n')[0], prometheus=('# HELP' in text and '# TYPE' in text), bytes=len(output))
                return info
    except (OSError, ssl.SSLError) as e:
        return dict(accepted=False, error=str(e))

def plain_http(port):
    try:
        with socket.create_connection(('127.0.0.1', port), timeout=8) as sock:
            sock.sendall(b'GET /metrics HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n')
            return sock.recv(16384).decode(errors='replace')
    except OSError as e:
        return str(e)

ENDPOINTS = {'controller-metrics': 19402, 'cainjector-metrics': 19403,
             'webhook-metrics': 19404, 'cert-manager-webhook': 19443,
             'trust-manager-webhook': 19444, 'operator-existing': 8443, 'operator-fresh': 28443}

def endpoints(minver, cipher_check=False):
    matrix = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        futures = {(name, ver): pool.submit(probe, port, ver) for name, port in ENDPOINTS.items() for ver in VERSIONS}
        for (name, ver), task in futures.items():
            obs = task.result()
            matrix.setdefault(name, {})[ver] = obs
            # Existing operator is deliberately checked for Day-2 adoption.
            expected = float(ver) >= float(minver)
            result(f'{name} TLS{ver}', obs['accepted'] == expected, obs, 'accept' if expected else 'reject')
    save(PHASE + '-handshakes', matrix)
    ca = public_cert('cert-manager-metrics-ca')
    for name, port in list(ENDPOINTS.items())[:3]:
        dns = {'controller-metrics':'cert-manager', 'cainjector-metrics':'cert-manager-cainjector', 'webhook-metrics':'cert-manager-webhook'}[name] + '.cert-manager.svc'
        obs = probe(port, '1.3', ca=ca, hostname=dns, http='/metrics')
        result(name + ' trusted HTTPS scrape', obs.get('prometheus') and '200' in obs.get('status',''), obs, 'CA and DNS verification; HTTP 200; Prometheus text')
        raw = plain_http(port)
        result(name + ' rejects plaintext scrape', '200 OK' not in raw and '# HELP' not in raw, raw[:300], 'HTTP 400 or connection rejection')
    for name, port, sec, key, dns in [
        ('trust-manager-webhook', 19444, 'trust-manager-tls', 'ca.crt', 'trust-manager.cert-manager.svc'),
        ('cert-manager-webhook', 19443, 'cert-manager-webhook-ca', 'tls.crt', 'cert-manager-webhook.cert-manager.svc')]:
        obs = probe(port, '1.3', ca=public_cert(sec,key), hostname=dns)
        result(name + ' CA/SAN validation', obs['accepted'], obs)
    raw = plain_http(19405)
    result('trust-manager metrics retain HTTP', '200 OK' in raw, raw[:180], 'HTTP remains supported; outside PR TLS scope')
    if cipher_check:
        for name, port in ENDPOINTS.items():
            allowed = probe(port, '1.2', 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256')
            denied = probe(port, '1.2', 'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384')
            result(name + ' Custom allowed cipher', allowed['accepted'], allowed)
            result(name + ' Custom excluded cipher', not denied['accepted'], denied)

def expected_args(deps, minimum):
    problems = []
    for dep in deps['items']:
        name = dep['metadata']['name']
        if name not in NAMES:
            continue
        args = dep['spec']['template']['spec']['containers'][0]['args']
        amap = {s.split('=',1)[0]:s.split('=',1)[1] for s in args if '=' in s}
        prefixes = ['--tls'] if name == 'trust-manager' else ['--metrics-tls']
        if name == 'cert-manager-webhook':
            prefixes.append('--tls')
        for prefix in prefixes:
            if minimum is None:
                if prefix + '-min-version' in amap or prefix + '-cipher-suites' in amap:
                    problems.append(name + ': unexpected profile flags')
            elif amap.get(prefix + '-min-version') != 'VersionTLS' + minimum.replace('.',''):
                problems.append(name + ': minimum mismatch')
            elif minimum == '1.3' and prefix + '-cipher-suites' in amap:
                problems.append(name + ': TLS1.3 cipher flag remains')
            elif minimum != '1.3' and not amap.get(prefix + '-cipher-suites'):
                problems.append(name + ': missing cipher flag')
        if name != 'trust-manager':
            if amap.get('--metrics-dynamic-serving-ca-secret-name') != 'cert-manager-metrics-ca':
                problems.append(name + ': missing dynamic-serving CA')
            if dep['spec']['template']['metadata'].get('annotations',{}).get('prometheus.io/scheme') != 'https':
                problems.append(name + ': missing https annotation')
        if len(amap) != len([s for s in args if '=' in s]):
            problems.append(name + ': duplicate flags')
        st = dep.get('status',{})
        if st.get('observedGeneration',0) < dep['metadata']['generation'] or st.get('updatedReplicas',0) != 1 or st.get('readyReplicas',0) != 1 or st.get('replicas',0) != 1:
            problems.append(name + ': rollout incomplete')
    return problems

def converge(minimum, timeout=240):
    end = time.monotonic() + timeout
    last = []
    while time.monotonic() < end:
        try:
            deps = get('deploy', '-n', 'cert-manager')
            last = expected_args(deps, minimum)
            if not last:
                save(PHASE + '-deployments', deps)
                result('deployment arguments and rollout', True, {d['metadata']['name']:d['spec']['template']['spec']['containers'][0]['args'] for d in deps['items']})
                return True
        except Exception as e:
            last = [str(e)]
        time.sleep(4)
    result('deployment arguments and rollout', False, last)
    return False

def patch_tls(adherence, profile, dry=False):
    ops = [{'op':'add','path':'/spec/tlsAdherence','value':adherence},
           {'op':'add','path':'/spec/tlsSecurityProfile','value':profile}]
    args = ['patch','apiserver','cluster','--type=json','-p',json.dumps(ops)]
    if dry:
        args.append('--dry-run=server')
    return oc(*args, check=not dry)

def restore():
    original = json.loads((OUT / 'original-apiserver.json').read_text())['spec']
    patch = {'spec':{key:original.get(key) for key in ['tlsAdherence','tlsSecurityProfile']}}
    if not original.get('tlsAdherence'):
        # OpenShift CEL forbids removing this field once set. Explicit Legacy
        # reproduces the original omitted-field semantics; preserve this delta.
        patch['spec']['tlsAdherence'] = 'LegacyAdheringComponentsOnly'
    for attempt in range(8):
        try:
            oc('patch','apiserver','cluster','--type=merge','-p',json.dumps(patch))
            result('restore original effective APIServer TLS behavior', True, get('apiserver','cluster')['spec'], 'original profile; explicit Legacy because removal is forbidden by OpenShift CEL')
            return
        except Exception:
            if attempt == 7:
                raise
            time.sleep(4)

def functional():
    issuer = {'apiVersion':'cert-manager.io/v1','kind':'Issuer','metadata':{'name':'qa-selfsigned','namespace':NS},'spec':{'selfSigned':{}}}
    cert = {'apiVersion':'cert-manager.io/v1','kind':'Certificate','metadata':{'name':'qa-certificate','namespace':NS},'spec':{'secretName':'qa-certificate','dnsNames':[f'{PHASE}.example.test'],'issuerRef':{'name':'qa-selfsigned'},'privateKey':{'rotationPolicy':'Always'}}}
    apply(issuer)
    apply(cert)
    end = time.monotonic() + 90
    obs = {}
    while time.monotonic() < end:
        obs = get('certificate','qa-certificate','-n',NS)
        if any(c['type']=='Ready' and c['status']=='True' and c.get('observedGeneration')==obs['metadata']['generation'] for c in obs.get('status',{}).get('conditions',[])):
            break
        time.sleep(3)
    ready = any(c['type']=='Ready' and c['status']=='True' and c.get('observedGeneration')==obs['metadata']['generation'] for c in obs.get('status',{}).get('conditions',[]))
    result('certificate admission and issuance/reissuance', ready, obs.get('status',{}))
    # Change the target each phase, forcing fresh admission and reconciliation.
    # A previously True condition alone would not prove the new spec was applied.
    key = 'trust-bundle-' + PHASE + '.pem'
    bundle = {'apiVersion':'trust.cert-manager.io/v1alpha1','kind':'Bundle','metadata':{'name':NS},'spec':{'sources':[{'configMap':{'name':'cmo-pr466-source','key':'ca.crt'}}],'target':{'configMap':{'key':key},'namespaceSelector':{'matchLabels':{'cmo-pr466-qa':'true'}}}}}
    apply(bundle)
    end = time.monotonic() + 90
    cm = {}; observed = {}; synced = False
    while time.monotonic() < end:
        observed = get('bundle',NS)
        synced = any(c['type']=='Synced' and c['status']=='True' and c.get('observedGeneration')==observed['metadata']['generation'] for c in observed.get('status',{}).get('conditions',[]))
        if synced:
            cm = get('configmap',NS,'-n',NS)
            if key in cm.get('data',{}):
                break
        time.sleep(3)
    source = get('configmap','cmo-pr466-source','-n','cert-manager')['data']['ca.crt']
    def fingerprints(pem):
        return sorted(hashlib.sha256(ssl.PEM_cert_to_DER_cert(block)).hexdigest() for block in re.findall(r'-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----',pem,re.S))
    expected = fingerprints(source)
    actual = fingerprints(cm.get('data',{}).get(key,''))
    result('Bundle current-generation admission and exact CA distribution', synced and bool(expected) and actual==expected,
           {'generation':observed.get('metadata',{}).get('generation'),'conditions':observed.get('status',{}).get('conditions',[]),'target_key':key,'source_sha256':expected,'target_sha256':actual})
    tm = get('certificate','trust-manager','-n','cert-manager')
    result('trust-manager serving Certificate Ready', any(c['type']=='Ready' and c['status']=='True' for c in tm.get('status',{}).get('conditions',[])), tm.get('status',{}))

def baseline():
    global PHASE
    PHASE = 'baseline'
    save('original-apiserver',get('apiserver','cluster'))
    save('original-certmanager',get('certmanager','cluster'))
    snapshot('baseline')
    apply({'apiVersion':'v1','kind':'Namespace','metadata':{'name':NS,'labels':{'cmo-pr466-qa':'true'}}})
    apply({'apiVersion':'v1','kind':'ConfigMap','metadata':{'name':'cmo-pr466-source','namespace':'cert-manager'},'data':{'ca.crt':public_cert('cert-manager-metrics-ca')}})
    converge(None)
    try:
        forwards()
        follower()
        endpoints('1.2')
        functional()
    finally:
        stop_all()
    for sa in NAMES[:3]:
        for verb, name, expected in [('get','cert-manager-metrics-ca',True),('update','cert-manager-metrics-ca',True),('update','cmo-pr466-unrelated',False)]:
            # The main controller already manages arbitrary certificate Secrets.
            # Scope the new metrics Role separately; aggregate RBAC is additive.
            if sa == 'cert-manager' and verb == 'update':
                expected = True
            p=oc('auth','can-i',verb,'secrets/'+name,'-n','cert-manager','--as=system:serviceaccount:cert-manager:'+sa,check=False)
            result(f'RBAC {sa} {verb} {name}', (p.stdout.strip()=='yes')==expected,p.stdout.strip())

PROFILES = [
    ('strict-default','StrictAllComponents',None,'1.2'),
    ('strict-intermediate','StrictAllComponents',{'type':'Intermediate','intermediate':{}},'1.2'),
    ('strict-modern','StrictAllComponents',{'type':'Modern','modern':{}},'1.3'),
    ('strict-custom12','StrictAllComponents',{'type':'Custom','custom':{'minTLSVersion':'VersionTLS12','ciphers':['ECDHE-ECDSA-AES128-GCM-SHA256','ECDHE-RSA-AES128-GCM-SHA256']}},'1.2'),
    ('strict-custom13','StrictAllComponents',{'type':'Custom','custom':{'minTLSVersion':'VersionTLS13','ciphers':[]}},'1.3'),
    ('strict-old','StrictAllComponents',{'type':'Old','old':{}},'1.0'),
    ('legacy-modern','LegacyAdheringComponentsOnly',{'type':'Modern','modern':{}},None),
]

def wait_platform(timeout=3600, require_settled=False):
    """Require stable API/availability; use full convergence for final cleanup."""
    end = time.monotonic() + timeout
    last = []
    healthy_samples = 0
    while time.monotonic() < end:
        try:
            operators = get('clusteroperators')
            last = []
            for item in operators['items']:
                conditions = {c['type']:c['status'] for c in item['status']['conditions']}
                if conditions.get('Available') != 'True' or conditions.get('Degraded') == 'True' or (require_settled and conditions.get('Progressing') == 'True'):
                    last.append(item['metadata']['name'])
            if not last:
                healthy_samples += 1
                if require_settled or healthy_samples >= 2:
                    save(PHASE + '-platform-stable', operators)
                    result('platform operators settled' if require_settled else 'platform available for testing', True,
                           'all Available=True, Degraded=False; '+('Progressing=False' if require_settled else 'two successful API samples, 15s apart; platform rollouts may continue'))
                    return True
            else:
                healthy_samples = 0
            print('Waiting for platform rollout: '+', '.join(last), flush=True)
        except Exception as e:
            print('Waiting for API recovery: '+str(e)[:160], flush=True)
        time.sleep(15)
    result('platform operators settled', False, last)
    return False

def profiles(selected=None):
    global PHASE
    try:
        for name, adherence, profile, minimum in PROFILES:
            if selected and name not in selected:
                continue
            PHASE = name
            print(f'BEGIN {PHASE} {stamp()}', flush=True)
            if not wait_platform():
                raise RuntimeError('Platform did not settle before the next TLS profile')
            patch_tls(adherence,profile)
            if not converge(minimum):
                continue
            try:
                forwards()
                follower()
                endpoints(minimum or '1.2', name=='strict-custom12')
                functional()
            finally:
                stop_all()
            snapshot(name)
    finally:
        PHASE = 'restore'
        stop_all()
        restore()
        converge(None)

def cleanup():
    global PHASE
    PHASE='cleanup'
    restore()
    oc('delete','bundle',NS,'--ignore-not-found')
    oc('delete','configmap','cmo-pr466-source','-n','cert-manager','--ignore-not-found')
    oc('delete','namespace',NS,'--ignore-not-found','--wait=false')
    converge(None)
    wait_platform(require_settled=True)
    snapshot('final')

if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    mode = sys.argv[1]
    if mode=='baseline':
        baseline()
    elif mode=='profiles':
        profiles(sys.argv[2:] or None)
    elif mode=='cleanup':
        cleanup()
    elif mode=='functional':
        PHASE='final-functional'
        functional()
    elif mode=='restore':
        restore()
    else:
        raise SystemExit('Use baseline, profiles [names...], functional, restore, cleanup')
