#!/usr/bin/env python3
"""Validate HTTP-to-HTTPS ServiceMonitor migration with real OpenShift UWM."""
import json
import time
import urllib.request
import live_check as q
PROM_PORT=19091

def wait(check, timeout, message):
    end=time.monotonic()+timeout
    last_print=0
    while time.monotonic()<end:
        try:
            value=check()
            if value:
                return value
        except Exception as e:
            if time.monotonic()-last_print>25:
                print(message+': '+str(e)[:180],flush=True)
                last_print=time.monotonic()
        if time.monotonic()-last_print>25:
            print(message,flush=True);last_print=time.monotonic()
        time.sleep(5)
    return None

def monitor(name, component=None, scheme=None):
    selector={'matchLabels':{'app.kubernetes.io/instance':'cert-manager'}}
    if component:
        selector['matchLabels']['app.kubernetes.io/component']=component
    else:
        selector['matchExpressions']=[{'key':'app.kubernetes.io/component','operator':'In','values':['controller','webhook','cainjector']}]
    endpoint={'honorLabels':False,'interval':'15s','path':'/metrics','scrapeTimeout':'10s','targetPort':9402}
    if scheme:
        svc={'controller':'cert-manager','webhook':'cert-manager-webhook','cainjector':'cert-manager-cainjector'}[component]
        endpoint.update(scheme='https',tlsConfig={'ca':{'secret':{'name':'cert-manager-metrics-ca','key':'tls.crt'}},'serverName':svc+'.cert-manager.svc'})
    return {'apiVersion':'monitoring.coreos.com/v1','kind':'ServiceMonitor','metadata':{'name':name,'namespace':'cert-manager'},'spec':{'selector':selector,'endpoints':[endpoint]}}

def targets():
    with urllib.request.urlopen('http://127.0.0.1:'+str(PROM_PORT)+'/api/v1/targets',timeout=10) as r:
        items=json.load(r)['data']['activeTargets']
    return [x for x in items if 'cmo-pr466' in x.get('scrapePool','')]

def main():
    q.OUT=q.OUT/'monitoring'
    q.OUT.mkdir(exist_ok=True)
    q.PHASE='monitoring'
    if not q.wait_platform():
        raise RuntimeError('Platform must settle before end-to-end monitoring testing')
    current=q.get('configmap','cluster-monitoring-config','-n','openshift-monitoring')
    backup=q.OUT/'original-cluster-monitoring-config.json'
    original=json.loads(backup.read_text()) if backup.exists() else current
    old=original.get('data',{}).get('config.yaml','')
    if 'enableUserWorkload:' in old:
        raise RuntimeError('Review existing enableUserWorkload setting before running this isolated-cluster recipe')
    new=old+'\nenableUserWorkload: true\n'
    if current['metadata']['uid']!=original['metadata']['uid'] or current.get('data',{}).get('config.yaml') not in [old,new]:
        raise RuntimeError('Monitoring config differs from both the baseline and this QA run; preserve the concurrent change')
    if not backup.exists():
        q.save('original-cluster-monitoring-config',original)
    names=['cmo-pr466-http']+['cmo-pr466-https-'+c for c in ['controller','webhook','cainjector']]
    try:
        q.oc('patch','configmap','cluster-monitoring-config','-n','openshift-monitoring','--type=merge','-p',json.dumps({'data':{'config.yaml':new}}))
        def ready():
            pods=q.get('pods','-n','openshift-user-workload-monitoring','-l','app.kubernetes.io/name=prometheus')['items']
            for p in pods:
                if p['status'].get('phase')=='Running' and p['status'].get('containerStatuses') and all(s.get('ready') for s in p['status']['containerStatuses']):
                    return p['metadata']['name']
        pod=wait(ready,480,'Waiting for OpenShift user-workload Prometheus')
        q.result('user-workload Prometheus starts',bool(pod),pod)
        if not pod:
            return
        process=q.background(q.OC+['port-forward','-n','openshift-user-workload-monitoring','pod/'+pod,str(PROM_PORT)+':9090'],'prometheus-forward')
        q.wait_port(PROM_PORT,process)
        q.apply(monitor(names[0]))
        def http_seen():
            items=targets()
            return items if len(items)==3 and all(t['health']=='down' and '400' in t['lastError'] for t in items) else None
        observed=wait(http_seen,180,'Waiting for documented HTTP ServiceMonitor results')
        observed=observed or targets()
        q.save('monitoring-http-targets',observed)
        q.result('documented HTTP ServiceMonitor fails on HTTPS metrics',len(observed)==3 and all(t['health']=='down' and '400' in t['lastError'] for t in observed),[{'url':t['scrapeUrl'],'health':t['health'],'error':t['lastError']} for t in observed],'three HTTP 400 targets reproduce documentation regression')
        q.oc('delete','servicemonitor',names[0],'-n','cert-manager')
        for c in ['controller','webhook','cainjector']:
            q.apply(monitor('cmo-pr466-https-'+c,c,'https'))
        def https_seen():
            items=[x for x in targets() if 'https-' in x['scrapePool']]
            return items if len(items)==3 and all(t['health']=='up' and not t['lastError'] for t in items) else None
        observed=wait(https_seen,180,'Waiting for CA-verified HTTPS scrape results')
        observed=observed or targets()
        q.save('monitoring-https-targets',observed)
        q.result('CA-verified HTTPS ServiceMonitors scrape all operands',len(observed)==3 and all(t['health']=='up' and not t['lastError'] for t in observed),[{'url':t['scrapeUrl'],'health':t['health'],'error':t['lastError']} for t in observed],'all three targets UP with CA and DNS verification')
    finally:
        q.stop_all()
        q.oc('delete','servicemonitor',*names,'-n','cert-manager','--ignore-not-found')
        q.oc('patch','configmap','cluster-monitoring-config','-n','openshift-monitoring','--type=json','-p',json.dumps([{'op':'test','path':'/data/config.yaml','value':new},{'op':'replace','path':'/data/config.yaml','value':old}]))
        restored=q.get('configmap','cluster-monitoring-config','-n','openshift-monitoring').get('data')==original.get('data')
        q.result('restore original monitoring configuration',restored,'ConfigMap data equals original')

if __name__=='__main__':
    main()
