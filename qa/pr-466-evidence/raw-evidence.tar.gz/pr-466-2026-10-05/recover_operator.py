#!/usr/bin/env python3
"""Restart the existing local binary using this checkout's make local-run settings."""
import json
import os
import socket
import subprocess
import time
import live_check as q

try:
    with socket.create_connection(('127.0.0.1',8443),timeout=1):
        raise SystemExit('Port 8443 is already active; no operator was started')
except OSError:
    pass
env=os.environ.copy()
env.update({
    'KUBECONFIG':str(q.KUBE),
    'RELATED_IMAGE_CERT_MANAGER_WEBHOOK':'quay.io/jetstack/cert-manager-webhook:v1.20.3',
    'RELATED_IMAGE_CERT_MANAGER_CA_INJECTOR':'quay.io/jetstack/cert-manager-cainjector:v1.20.3',
    'RELATED_IMAGE_CERT_MANAGER_CONTROLLER':'quay.io/jetstack/cert-manager-controller:v1.20.3',
    'RELATED_IMAGE_CERT_MANAGER_ACMESOLVER':'quay.io/jetstack/cert-manager-acmesolver:v1.20.3',
    'RELATED_IMAGE_CERT_MANAGER_ISTIOCSR':'quay.io/jetstack/cert-manager-istio-csr:v0.16.0',
    'RELATED_IMAGE_CERT_MANAGER_TRUST_MANAGER':'quay.io/jetstack/trust-manager:v0.20.3',
    'OPERATOR_NAME':'cert-manager-operator','OPERAND_IMAGE_VERSION':'1.20.0',
    'ISTIOCSR_OPERAND_IMAGE_VERSION':'v0.16.0','TRUSTMANAGER_OPERAND_IMAGE_VERSION':'v0.20.3',
    'OPERATOR_IMAGE_VERSION':'1.20.0',
})
args=[str(q.ROOT/'cert-manager-operator'),'start','--config=./hack/local-run-config.yaml',
      '--kubeconfig='+str(q.KUBE),'--namespace=cert-manager-operator','--unsupported-addon-features=TrustManager=true']
with (q.OUT/'restarted-local-operator.log').open('a') as log:
    p=subprocess.Popen(args,env=env,cwd=q.ROOT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
q.save('restarted-local-operator',{'pid':p.pid,'time':q.stamp(),'command':args,'settings':'same explicit image/version values as make local-run'})
q.wait_port(8443,p,90)
time.sleep(10)
if p.poll() is not None:
    raise SystemExit('Operator exited during startup; inspect restarted-local-operator.log')
print('Local operator restarted, PID',p.pid,flush=True)
