# PR #466 — independent reproduction on the replacement cluster

This run checks the five previously failed operator TLS assertions and the HTTP ServiceMonitor incompatibility. The first run's files in `../pr-466-2026-10-05/` are preserved.

For team cross-verification without the Python drivers, use the report's [manual reproduction appendix](REPORT.md#manual-reproduction-appendix), including expected/actual results and restoration commands.

## Environment

| Item | Replacement-cluster run |
|---|---|
| PR commit | `b116f756e5333645814aeabfc0569933111bc5be` |
| Branch | `trustmanager_tls_impl` |
| Kubeconfig | Repository-root `kubeconfig`; contents are excluded from evidence |
| Cluster | `ci-op-32nzi86y-ea007-6xtww`, AWS `us-east-1` |
| Cluster UID | `9934356c-e49c-4741-b314-48b9db1f2716` |
| OpenShift | `5.1.0-0.ci-2026-10-05-053659-test-ci-op-32nzi86y-latest` |
| Local operator | Go 1.26.0, macOS arm64; PID `96017` initially, PID `1316` after API-outage recovery |
| cert-manager images | Upstream `v1.20.3` |
| trust-manager image | Upstream `v0.20.3` |

The initial platform had all 35 ClusterOperators Available, nonprogressing and nondegraded. The operator Deployment already existed at zero replicas, and no CertManager/TrustManager CRs existed. The local binary was rebuilt using `make build-operator`, preserving the existing tracked edits. That target completed successfully with the expected non-FIPS local-toolchain warning; Go also reported a nonfatal sandbox denial while writing module stat cache. No FIPS or production-image claim is made.

`setup.py` saved the original cluster state, created the minimal CertManager and TrustManager instances, and launched the local operator with explicit `KUBECONFIG`, the kubeconfig command-line flag, Makefile image/version values, and `TrustManager=true`. Each valid comparison retains the same baseline process across its policy change. An API outage forced a replacement baseline process for the last two profiles; their identities and measurements are kept separate.

## Executed procedure

Commands are run from the repository root; each driver passes the new kubeconfig explicitly.

```sh
make build-operator
python3 qa/pr-466-repro-2026-10-05/setup.py
python3 qa/pr-466-repro-2026-10-05/live_check.py baseline
python3 qa/pr-466-repro-2026-10-05/monitoring_check.py
python3 qa/pr-466-repro-2026-10-05/reproduce.py
```

The initial attempt was interrupted by API timeouts and leader-lease loss. After its restoration attempt completed and the API became usable, these recovery/resume commands were executed:

```sh
python3 qa/pr-466-repro-2026-10-05/resume_operator.py
python3 qa/pr-466-repro-2026-10-05/reproduce.py strict-custom13 strict-old
python3 qa/pr-466-repro-2026-10-05/finish.py
python3 qa/pr-466-repro-2026-10-05/render_checks.py
```

The baseline TLS checks and monitoring setup can run together; TLS policy changes begin after both finish. Do not replay these commands against this evidence directory: preserve its original-object backups and results.

### Baseline and monitoring

1. Save original APIServer and CertManager configuration. Create a disposable namespace, Issuer, Certificate, Bundle and public CA source ConfigMap.
2. Verify TLS 1.0/1.1 rejection and TLS 1.2/1.3 acceptance on the existing operator, a fresh follower and five operand TLS endpoints.
3. Check trusted HTTPS metrics, webhook CA/DNS identities, current-generation Certificate issuance and exact Bundle CA distribution.
4. Temporarily enable user-workload monitoring, preserving the original monitoring ConfigMap data.
5. Apply a ServiceMonitor equivalent to the documentation's HTTP example; record all three Prometheus target health/error fields.
6. Replace it with three HTTPS ServiceMonitors using `cert-manager-metrics-ca` and component-specific Service DNS names, with certificate verification enabled. Record target health/errors again.
7. Remove those monitors and restore the exact monitoring ConfigMap data before TLS profile changes.

### TLS policy reproduction

For each profile below, replace the entire APIServer profile union, wait for all four operand Deployments to roll out, and select Ready pods with current arguments. Compare the existing operator on local port 8443 against a fresh follower on 28443 and the five operand endpoints. The follower shares the same leader lock; record that it does not replace the leader.

| Cluster policy (`StrictAllComponents`) | Previously failed probe | Correct policy behavior |
|---|---|---|
| Modern | TLS 1.2 | Reject |
| Custom minimum 1.2, only ECDHE AES128-GCM RSA/ECDSA | Excluded AES256-GCM ECDHE cipher | Reject |
| Custom minimum 1.3, empty cipher list | TLS 1.2 | Reject |
| Old | TLS 1.0 | Accept |
| Old | TLS 1.1 | Accept |

Each comparison is repeated after three seconds. Require a real TLS alert for rejection, an active TLS 1.3 positive control, and the original operator's unchanged certificate fingerprint. This prevents treating an unavailable listener as a policy rejection. Record PID and leader identity. Run current-generation Certificate and Bundle checks in each profile.

The driver restores the original effective TLS configuration in `finally`. OpenShift forbids removing `tlsAdherence` once it is set, so a previously absent field is restored as explicit `LegacyAdheringComponentsOnly` with no profile. This known spec difference is recorded. Feature checks wait for operand convergence; broad platform/node recovery is observed separately and is not a completion gate for this focused run.

## Execution qualifications

The first Custom TLS 1.3 attempt encountered API read timeouts. The initial operator's log explicitly records failed lease renewal and `leader election lost` at 10:11:57 UTC (15:41:57 in the host-time log). Its metrics listener then refused connections. Four protocol observations and the repeated comparison from that unavailable listener are shown as INTERRUPTED in CHECKS.md, regardless of their initial raw Boolean pass/fail. A rollback convergence wait also timed out on API reads and is marked INTERRUPTED. The original raw records remain unchanged.

The replacement operator was started with baseline TLS behavior, and baseline operand convergence was verified before retrying. The driver now checks original-listener liveness again after rollout, and negative protocol/cipher assertions require TLS alerts rather than transport errors. The valid Modern and Custom cipher results precede the outage. The resumed Custom TLS 1.3 and Old cases use the replacement baseline. This separates policy behavior from the availability incident.

Certificate and Bundle specs vary by profile. The Custom TLS 1.3 retry reused its earlier spec and confirmed the current Ready/Synced generation; the earlier attempt had already performed fresh admission under that same cluster policy. The final functional check uses a new spec again.

## Evidence

- `evidence/commands.log`: executed API commands, manifests, stdout/stderr and exit codes.
- `evidence/results.jsonl`: assertions including actual protocol/cipher negotiations and errors.
- `evidence/*-handshakes.json`: full protocol matrices.
- `evidence/*-repeat-comparisons.json`: repeated existing-versus-fresh comparisons and positive controls.
- `evidence/*-deployments.json`: actual operand arguments and rollout status.
- `evidence/monitoring/`: separate commands/results, original monitoring data and Prometheus target snapshots.
- `evidence/restarted-local-operator.json` and `.log`: persistent local operator launch details and logs.
- `evidence/initial-local-operator.json` and `.log`, `evidence/interrupted-custom13/`, `evidence/recovery/`: original process, interrupted measurements, and recovery details.
- `evidence/active-listener-baseline.json`: replacement process identity and baseline protocol controls.
- `evidence/binary.json`, `git-head.txt`, `pre-existing-local-changes.patch`: build and worktree identity.

No kubeconfig contents, bearer tokens or private keys are collected. A zero driver exit code does not imply all assertions passed: feature failures are recorded while the driver continues gathering controls and restoring configuration.
