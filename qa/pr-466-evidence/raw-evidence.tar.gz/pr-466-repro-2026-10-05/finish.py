#!/usr/bin/env python3
"""Remove disposable QA resources and record final feature state without waiting for platform recovery."""
import json
import datetime
import os
import socket
import time
import live_check as q

q.PHASE='cleanup'
original=json.loads((q.OUT/'original-apiserver.json').read_text())['spec']
expected=dict(original)
expected['tlsAdherence']='LegacyAdheringComponentsOnly'
if q.get('apiserver','cluster')['spec']!=expected:
    q.restore()
q.result('original effective TLS behavior restored',q.get('apiserver','cluster')['spec']==expected,q.get('apiserver','cluster')['spec'])
q.converge(None,timeout=300)
q.PHASE='final-functional'
q.functional()
q.PHASE='cleanup'
for kind,name,namespace in [('bundle',q.NS,None),('configmap','cmo-pr466-source','cert-manager'),('namespace',q.NS,None)]:
    args=['delete',kind,name,'--ignore-not-found','--wait=false']
    if namespace:
        args+=['-n',namespace]
    q.oc(*args)
end=time.monotonic()+90
while time.monotonic()<end:
    p=q.oc('get','namespace',q.NS,'--ignore-not-found','-o','name')
    if not p.stdout.strip():
        break
    time.sleep(3)
q.result('disposable QA namespace removed',not p.stdout.strip(),p.stdout.strip() or 'absent')
for kind,name,namespace in [('bundle',q.NS,None),('configmap','cmo-pr466-source','cert-manager')]:
    args=['get',kind,name,'--ignore-not-found','-o','name']
    if namespace:
        args+=['-n',namespace]
    p=q.oc(*args)
    q.result('QA '+kind+' removed',not p.stdout.strip(),p.stdout.strip() or 'absent')
monitors=q.get('servicemonitor','-n','cert-manager')['items']
remaining=[x['metadata']['name'] for x in monitors if x['metadata']['name'].startswith('cmo-pr466-')]
q.result('QA ServiceMonitors removed',not remaining,remaining)
monitoring=q.get('configmap','cluster-monitoring-config','-n','openshift-monitoring')
original_monitoring=json.loads((q.OUT/'monitoring/original-cluster-monitoring-config.json').read_text())
q.result('monitoring configuration restored exactly',monitoring.get('data')==original_monitoring.get('data'),'current and original ConfigMap data match')
leader=q.get('lease','cert-manager-operator-lock','-n','cert-manager-operator')['spec']
records=[json.loads(s) for s in (q.OUT/'results.jsonl').read_text().splitlines()]
expected_leader=next(x['observed']['after'] for x in reversed(records) if x['test']=='follower preserves existing leader')
renew=datetime.datetime.fromisoformat(leader['renewTime'].replace('Z','+00:00'))
age=(datetime.datetime.now(datetime.timezone.utc)-renew).total_seconds()
q.result('replacement operator retains an actively renewed leader lease',leader['holderIdentity']==expected_leader and age<60,{'holder':leader['holderIdentity'],'renew_age_seconds':age})
pid=json.loads((q.OUT/'restarted-local-operator.json').read_text())['pid']
os.kill(pid,0)
probe=q.probe(8443,'1.3')
baseline=json.loads((q.OUT/'baseline-handshakes.json').read_text())['operator-existing']['1.3']
if (q.OUT/'active-listener-baseline.json').exists():
    baseline=json.loads((q.OUT/'active-listener-baseline.json').read_text())['protocols']['1.3']
q.result('same local operator remains running',probe.get('accepted') and probe.get('certificate_sha256')==baseline['certificate_sha256'],{'pid':pid,'leader':leader,'probe':probe})
open_ports=[]
for port in [19402,19403,19404,19443,19444,19405,28443,19091]:
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.5):
            open_ports.append(port)
    except OSError:
        pass
q.result('temporary followers and forwards stopped',not open_ports,open_ports)
state=q.snapshot('final')
q.save('final-observation',{'time':q.stamp(),'local_operator_pid':pid,'platform_conditions':{x['metadata']['name']:{c['type']:c['status'] for c in x['status']['conditions'] if c['type'] in ['Available','Progressing','Degraded']} for x in state['clusteroperators']['items']},'note':'Platform recovery recorded but not awaited, per user preference. Local operator and installed operands intentionally remain running.'})
