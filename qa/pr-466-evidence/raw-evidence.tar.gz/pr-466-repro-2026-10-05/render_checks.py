#!/usr/bin/env python3
"""Render assertions, explicitly qualifying measurements interrupted by listener loss."""
import collections
import json
from pathlib import Path

root=Path(__file__).resolve().parent
items=[]
for source in (root/'evidence').rglob('results.jsonl'):
    for line in source.read_text().splitlines():
        item=json.loads(line)
        item['source']=str(source.relative_to(root))
        obs=item['observed']
        unavailable=isinstance(obs,dict) and 'Connection refused' in obs.get('error','')
        lost_control=isinstance(obs,dict) and 'positive_control' in obs and not obs['positive_control'].get('accepted')
        if unavailable or lost_control:
            item['raw_result']=item['result']
            item['result']='INTERRUPTED'
            item['observed']={'raw_result':item['raw_result'],'qualification':'Original operator lost leadership during API outage; unavailable listener is not a TLS policy measurement. Retried with a replacement baseline leader.','measurement':obs}
        elif item['phase']=='restore' and item['test']=='deployment arguments and rollout' and item['result']=='FAIL':
            item['raw_result']=item['result']
            item['result']='INTERRUPTED'
            item['observed']={'raw_result':'FAIL','qualification':'Rollback wait encountered API read timeouts while the replacement leader was waiting to acquire its lease. Baseline convergence is checked again before the resumed cases.','measurement':obs}
        items.append(item)
items.sort(key=lambda x:x['time'])
counts=collections.Counter(x['result'] for x in items)
lines=['# Independent reproduction — executed assertions','',
       'Counts: '+', '.join(str(n)+' '+k for k,n in sorted(counts.items()))+'. Counts are assertions, not unique scenarios.','',
       'See [README.md](README.md) for the procedure. Expected-failure reproduction checks can PASS while confirming a product finding. Connection-refused observations and comparisons with a lost positive control are shown as INTERRUPTED; original raw results remain unchanged in the linked logs.','',
       '| ID | UTC time | Phase | Result | Check | Expected | Observation | Evidence |',
       '|---|---|---|---|---|---|---|---|']
def cell(value):
    return str(value).replace('|','&#124;').replace('\n','<br>').replace('\r','')
for index,x in enumerate(items,1):
    observed=x['observed']
    if x['test']=='deployment arguments and rollout' and x['result']=='PASS':
        observed='Expected TLS/HTTPS flags and completed rollouts; full arguments in linked evidence.'
    elif isinstance(observed,dict) and 'accepted' in observed:
        observed={k:v for k,v in observed.items() if k in ['accepted','protocol','cipher','error','status','prometheus']}
    elif isinstance(observed,dict) and 'existing' in observed:
        observed={k:observed[k] for k in ['protocol','reproduced','same_pid']}
    elif isinstance(observed,dict) and 'conditions' in observed:
        observed={k:v for k,v in observed.items() if k in ['conditions','generation','revision','target_key','source_sha256','target_sha256']}
    text=json.dumps(observed) if isinstance(observed,(list,dict)) else observed
    lines.append('| '+' | '.join(cell(v) for v in [f'R-{index:03d}',x['time'][11:19],x['phase'],x['result'],x['test'],x['expected'] or 'As described in procedure',text,'[raw]('+x['source']+')'])+' |')
(root/'CHECKS.md').write_text('\n'.join(lines)+'\n')
(root/'evidence/assertion-summary.json').write_text(json.dumps(dict(counts),indent=2)+'\n')
print(dict(counts))
