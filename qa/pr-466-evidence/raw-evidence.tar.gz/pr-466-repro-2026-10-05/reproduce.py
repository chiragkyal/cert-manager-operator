#!/usr/bin/env python3
"""Focused independent reproductions of the five operator TLS assertions."""
import json
import os
import sys
import time
import live_check as q

selected=sys.argv[1:] or ['strict-modern','strict-custom12','strict-custom13','strict-old']
baseline=json.loads((q.OUT/'baseline-handshakes.json').read_text())
active_baseline=q.OUT/'active-listener-baseline.json'
fingerprint=(json.loads(active_baseline.read_text())['protocols']['1.3'] if active_baseline.exists() else baseline['operator-existing']['1.3'])['certificate_sha256']
pid=json.loads((q.OUT/'restarted-local-operator.json').read_text())['pid']
if active_baseline.exists():
    q.PHASE='resume-baseline'
    config=q.get('apiserver','cluster')['spec']
    assert config.get('tlsAdherence')=='LegacyAdheringComponentsOnly' and not config.get('tlsSecurityProfile'),config
    if not q.converge(None,timeout=300):
        raise RuntimeError('Replacement leader has not reconciled the baseline')
try:
    for name,adherence,profile,minimum in q.PROFILES:
        if name not in selected:
            continue
        q.PHASE=name
        print('BEGIN '+name+' '+q.stamp(),flush=True)
        os.kill(pid,0)
        positive=q.probe(8443,'1.3')
        same=positive.get('accepted') and positive.get('certificate_sha256')==fingerprint
        q.result('same original operator listener before policy change',same,{'pid':pid,'probe':positive})
        if not same:
            raise RuntimeError('Original listener lost; cannot attribute results to policy adoption')
        q.save(name+'-before-apiserver',q.get('apiserver','cluster'))
        q.patch_tls(adherence,profile)
        if not q.converge(minimum,timeout=300):
            raise RuntimeError('Operand controls failed to converge')
        control=q.probe(8443,'1.3')
        if not control.get('accepted') or control.get('certificate_sha256')!=fingerprint:
            raise RuntimeError('Original listener was lost during rollout; stage requires recovery and retry')
        try:
            q.forwards()
            q.follower()
            q.endpoints(minimum,name=='strict-custom12')
            # Repeat each failing comparison, retaining the TLS1.3 positive
            # control and fingerprint of the exact same original process.
            repetitions=[]
            for version in (['1.0','1.1'] if name=='strict-old' else ['1.2']):
                cipher='ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384' if name=='strict-custom12' else None
                time.sleep(3)
                old=q.probe(8443,version,cipher)
                fresh=q.probe(q.FOLLOWER_PORT,version,cipher)
                control=q.probe(8443,'1.3')
                expected_old=name!='strict-old'
                tls_rejection=fresh if expected_old else old
                reproduced=(old['accepted']==expected_old and fresh['accepted']!=expected_old
                    and 'ALERT_' in tls_rejection.get('error','')
                    and control.get('accepted') and control.get('certificate_sha256')==fingerprint)
                observation={'protocol':version,'cipher_offer':cipher,'existing':old,'fresh':fresh,'positive_control':control,'same_pid':pid,'reproduced':bool(reproduced)}
                repetitions.append(observation)
                q.result('F1 independently reproduced again for TLS'+version,bool(reproduced),observation,'old and fresh listeners disagree exactly as in first cluster, with TLS alert rejection and live positive control')
            q.save(name+'-repeat-comparisons',repetitions)
            q.functional()
        finally:
            q.stop_all()
        q.snapshot(name)
finally:
    q.PHASE='restore'
    q.stop_all()
    q.restore()
    q.converge(None,timeout=300)
