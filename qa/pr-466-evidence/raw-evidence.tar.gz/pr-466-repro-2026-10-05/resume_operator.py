#!/usr/bin/env python3
"""Preserve the outage evidence and restart a baseline leader for remaining cases."""
import json
import shutil
import sys
import live_check as q

base=q.OUT
archive=base/'interrupted-custom13'
archive.mkdir(exist_ok=True)
for p in base.glob('strict-custom13*'):
    if p.is_file():
        shutil.copy2(p,archive/p.name)
for name in ['restarted-local-operator.json','restarted-local-operator.log']:
    p=base/name
    target=base/name.replace('restarted','initial')
    if target.exists():
        raise RuntimeError('Original launch evidence already archived; review before another restart')
    p.rename(target)
q.OUT=base/'recovery'
q.OUT.mkdir(exist_ok=True)
q.PHASE='operator-recovery'
config=q.get('apiserver','cluster')['spec']
assert config.get('tlsAdherence')=='LegacyAdheringComponentsOnly' and not config.get('tlsSecurityProfile'),config
q.run([sys.executable,str(base.parent/'recover_operator.py')],timeout=130)
pid=json.loads((base/'restarted-local-operator.json').read_text())['pid']
probes={v:q.probe(8443,v) for v in q.VERSIONS}
ok=all(probes[v]['accepted']==(v in ['1.2','1.3']) for v in probes)
q.result('replacement local operator has verified baseline TLS policy',ok,{'pid':pid,'protocols':probes})
if not ok:
    raise RuntimeError('Replacement baseline TLS check failed')
(base/'active-listener-baseline.json').write_text(json.dumps({'time':q.stamp(),'pid':pid,'protocols':probes},indent=2)+'\n')
q.save('incident',{'reason':'Original local operator lost leader election during API read timeouts; original log records leader election lost at 15:41:57 IST (10:11:57 UTC). Interrupted Custom13 operator probes are not valid policy measurements.','initial_pid':96017,'replacement_pid':pid,'original_log':'../initial-local-operator.log','interrupted_artifacts':'../interrupted-custom13/'})
