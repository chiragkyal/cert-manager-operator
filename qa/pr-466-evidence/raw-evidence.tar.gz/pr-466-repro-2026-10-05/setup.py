#!/usr/bin/env python3
"""Start the same PR locally against the replacement cluster."""
import hashlib
import json
import sys
import time
import live_check as q

q.PHASE='setup'
q.save('cluster-version',q.get('clusterversion','version'))
q.save('infrastructure',q.get('infrastructure','cluster'))
q.save('initial-apiserver',q.get('apiserver','cluster'))
q.save('initial-platform',q.get('clusteroperators'))
q.save('initial-operator-deployment',q.get('deploy','-n','cert-manager-operator'))
q.save('initial-operator-crs',q.get('certmanager,trustmanager'))
q.save('binary',{'sha256':hashlib.sha256((q.ROOT/'cert-manager-operator').read_bytes()).hexdigest(),'build_info':q.run(['go','version','-m','cert-manager-operator']).stdout})
assert q.get('clusterversion','version')['metadata']['uid']!='6c0f4e8e-8bf0-4d09-abf1-68efcdc5d518','This is the original cluster'
assert not q.get('certmanager,trustmanager')['items'],'Review existing CRs before setup'
q.oc('apply','-f','config/samples/operator.openshift.io_v1alpha1_certmanager.yaml')
q.run([sys.executable,str(q.OUT.parent/'recover_operator.py')],timeout=130)
deadline=time.monotonic()+240
while time.monotonic()<deadline:
    deps=q.get('deploy','-n','cert-manager')['items']
    ready={d['metadata']['name'] for d in deps if d.get('status',{}).get('readyReplicas')==1}
    if set(q.NAMES[:3])<=ready:
        break
    print('Waiting for cert-manager operands: '+str(sorted(ready)),flush=True)
    time.sleep(5)
else:
    raise RuntimeError('cert-manager operands failed to become ready')
q.apply({'apiVersion':'operator.openshift.io/v1alpha1','kind':'TrustManager','metadata':{'name':'cluster'},'spec':{'trustManagerConfig':{}}})
if not q.converge(None,timeout=300):
    raise RuntimeError('Trust-manager installation did not converge')
q.result('new cluster local operator and four operands started',True,{'operator':json.loads((q.OUT/'restarted-local-operator.json').read_text()),'deployments':q.NAMES})
q.snapshot('installed')
